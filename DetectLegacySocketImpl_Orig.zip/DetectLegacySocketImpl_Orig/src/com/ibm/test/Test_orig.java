package com.ibm.test;

//import java.net.DatagramPacket;
import java.net.DatagramSocket;
//import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketAddress;

public class Test_orig {
    public static void main(String[] args) {
        try {
            String proxyHost = "proxy.example.com";
            int proxyPort = 1080;

            String serverHost = "example.com";
            int serverPort = 80;
            Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(proxyHost, proxyPort));

            SocketAddress destAddress = new InetSocketAddress(serverHost, serverPort);
            
            //flags
            DatagramSocket dgSocket = new DatagramSocket(destAddress);
            
            //flags
            MulticastSocket ms = new MulticastSocket(destAddress);
            
            // Create a socket with SocksSocketImpl
            //Socket(proxy) constructor --> SocketImpl.createPlatformSocketImpl --> PlainSocketImpl/NioSocketImpl
            //flags
            Socket socket = new Socket(proxy);
            socket.connect(destAddress);
            socket.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        
//        try {
        	// Set up the SOCKS proxy server address and port
//            String proxyHost = "proxy.example.com";
//            int proxyPort = 1080;
//
//            String serverHost = "example.com";
//            int serverPort = 80;
////            Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(proxyHost, proxyPort));
//
//            SocketAddress destAddress = new InetSocketAddress(serverHost, serverPort);
            
           

//            // Prepare data to send
//            String message = "Hello, UDP!";
//            byte[] sendData = message.getBytes();
//            InetAddress address = InetAddress.getByName("localhost");
//            int port = 12345;
//
//            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, address, port);
//            dgSocket.send(sendPacket);
//            ms.send(sendPacket);
//            System.out.println("Sent message: " + message);
//            byte[] receiveData = new byte[1024];
//            
//            //flags
//            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
//            dgSocket.receive(receivePacket);
//            String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
//            System.out.println("Received message: " + receivedMessage);
            dgSocket.close();
            ms.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
