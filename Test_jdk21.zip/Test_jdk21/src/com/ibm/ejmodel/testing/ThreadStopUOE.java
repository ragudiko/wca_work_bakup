package com.ibm.ejmodel.testing;


//suspend_resume_01

public class ThreadStopUOE extends Thread {

	String document = "Document1"; 
	public volatile boolean suspended = false;

	public synchronized void printDocument(String document) {
		while (!suspended) {
			System.out.println(Thread.currentThread().getName() + " printing sample document: " + document);
			try {
				wait(2000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
			System.out.println(Thread.currentThread().getName() + " done with printing document: " + document);
		}
	}

	@Override
	public void run() {
		printDocument(document);
	}

	public void suspendThread() {
		suspended = true;
	}

	public void resumeThread() {
		suspended = false;
		synchronized (this) {
			notify();
		}
	}

	public static void main(String[] args) {
		ThreadStopUOE printerSample = new ThreadStopUOE();

		printerSample.start();

		try {
			Thread.sleep(2000); 
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		System.out.println(" suspend the thread");
		printerSample.suspendThread();

		try {
			Thread.sleep(5000); 
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
		System.out.println(" resume the thread");
		printerSample.resumeThread();
		
	}
}

//public class ThreadStopUOE extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	wait();
//                }
//            } catch (InterruptedException e){
//            }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE threadExample = new ThreadStopUOE();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}


//public class ThreadStopUOE extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	wait();
//                }
//            } catch (InterruptedException e){
//            }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE threadExample = new ThreadStopUOE();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}

//ICL ouput
//public class ThreadStopUOE extends Thread {
//	
//	public volatile boolean suspended = false;
//	private boolean isStopped = false;
//
//	@Override
//    public void run() {
//        synchronized (this) {
//            while (!isStopped) {
//                if (suspended) {
//                    try {
//                        System.out.println("Thread suspended...");
//                        wait();
//                    } catch (InterruptedException e) {
//                        Thread.currentThread().interrupt();
//                    }
//                }
//                else
//                	System.out.println("Thread is running...");
//                try {
//                    Thread.sleep(1000);
//                } catch (InterruptedException e) {
//                    Thread.currentThread().interrupt();
//                }
//            }
//        }
//        System.out.println("Thread has stopped.");
//    }
//	
//	public void startThread() {
//		this.start();
//	}
//	
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			this.notify();
//		}
//	}
//
//	public void stopThread() {
//		synchronized (this) {
//			isStopped = true;
//			this.stop();
//			//this.notify(); // Wake up the thread to allow it to stop
//		}
//	}
//
//    public static void main(String[] args) {
//        ThreadStopUOE thread = new ThreadStopUOE();
//
//        thread.startThread();
//
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Suspending the thread...");
//        thread.suspendThread();
//
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Resuming the thread...");
//        thread.resumeThread();
//
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Stopping the thread...");
//        thread.stopThread();
//
//        System.out.println("Main thread finished.");
//    }
//}


//output

//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopUOE extends Thread {
//
//	private Thread myThread;
//	public volatile boolean suspended = false;
//	
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				if(suspended) {
//					synchronized (this) {
//						this.wait();
//					}
//				}
//					
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		this.notify();
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopUOE legacyThread = new ThreadStopUOE();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Start the Thread");
//		legacyThread.start();
//		
//		System.out.println("Suspend the Thread");
//		legacyThread.suspendThread();
//		
//		System.out.println("Resume the Thread");
//		legacyThread.resumeThread();
//
//	}
//
//}




//output
//public class ThreadStopUOE extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	wait();
//                }
//            } catch (InterruptedException e){
//            }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE threadExample = new ThreadStopUOE();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}
