package com.ibm.test;

import java.util.ArrayList;
import java.util.List;
//Assisted by WCA@IBM
//Latest GenAI contribution: ibm/granite-20b-code-instruct-v2
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class CustomLogManager3 {

	//private final List<Runnable> listeners = new ArrayList<>();

	public static void main(String[] args) {

		// Add a configuration listener
		final Runnable listener = () -> {
			System.out.println("Listener OK!");
		};

		//Logger logger = Logger.getLogger("");
		LogManager.getLogManager().addConfigurationListener(new Runnable() {
			@Override
			public void run() {
				System.out.println("A new logging configuration has been loaded");
			}
		});

		// Remove the configuration listener
		LogManager.getLogManager().removeConfigurationListener(listener);
	}
}
