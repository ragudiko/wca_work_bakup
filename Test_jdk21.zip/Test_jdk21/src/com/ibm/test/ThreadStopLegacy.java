package com.ibm.test;

//Ex_01
//public class ThreadStopLegacy extends Thread {
//    @Override
//    public void run() {
//        while(true) {
//            // keep doing what this thread should do.
//            System.out.println("Thread is Running");
//
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy legacyThread = new ThreadStopLegacy();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(9000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        legacyThread.stop();
//    }
//}
