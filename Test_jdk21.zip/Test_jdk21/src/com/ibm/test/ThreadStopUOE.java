package com.ibm.test;

public class ThreadStopUOE {
    public static void main(String[] args) {
        Thread myThread = new Thread(() -> {
            try {
                while (true) {
                    System.out.println("Thread is running...");
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        myThread.start();

        // Let the thread run for some time
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("Suspending the thread...");
//        myThread.suspend();

        System.out.println("Resuming the thread...");
        myThread.resume();

        myThread.stop();

        System.out.println("Thread stopped abruptly.");
    }
}
