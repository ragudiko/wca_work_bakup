package com.ibm.test;


public class ThreadObjectWaitNotify extends Thread {

	public volatile boolean suspended = false;

	@Override
	public void run() {
        while (true) {
            try {
                Thread.sleep(1000);

                synchronized(this) {
                    while (suspended) {
                    	try {
                    		this.wait();
                    	} catch (InterruptedException e) {
                    		e.printStackTrace();
                    	}
                    }
                }
            } catch (InterruptedException e){
            }
        }
    }

	public void suspendThread() {
		suspended = true;
	}

	public void resumeThread() {
		suspended = false;
		synchronized (this) {
			this.notify();
		}
	}
	

	public static void main(String[] args) {

		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();

		threadExample.start();
		System.out.println("Thread is running...");

		// Let the thread run for some time
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		System.out.println("Suspending the thread...");

		threadExample.suspendThread();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		System.out.println("Resuming the thread...");

		threadExample.resumeThread();

	}
}

//******* start of plab code ******************
//prompt_lab
//stop_01
//public class ThreadObjectWaitNotify extends Thread {
//    private volatile boolean shouldStop = false;
//
//    @Override
//    public void run() {
//        while(!shouldStop) {
//            // keep doing what this thread should do.
//            System.out.println("Thread is Running");
//
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//        }
//    }
//
//    public void setShouldStop(boolean shouldStop) {
//        this.shouldStop = shouldStop;
//    }
//
//    public boolean getShouldStop() {
//        return shouldStop;
//    }
//
//    public static void main(String[] args) {
//        ThreadObjectWaitNotify legacyThread = new ThreadObjectWaitNotify();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(9000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        System.out.println("Stop the Thread");
//        legacyThread.setShouldStop(true);
//    }
//}

//stop2
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadObjectWaitNotify extends Thread{
//
//	private volatile boolean doRun = true;
//	
//	@Override
//	public void run() {
//		try {
//			while (doRun) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void start() {
//		new Thread(this).start();
//	}
//
//	public void stopThread() {
//		doRun = false;
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadObjectWaitNotify threadStop = new ThreadObjectWaitNotify();
//		threadStop.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Start the Thread");
//		threadStop.start();
//		
//		System.out.println("Stop the Thread");
//		threadStop.stopThread();
//
//	}
//
//}

//public class ThreadObjectWaitNotify {
//    private static volatile boolean shouldStop = false;
//
//    public static void main(String[] args) {
//        Thread thread = new Thread(() -> {
//            while (!shouldStop) {
//                try {
//                    Thread.sleep(1000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        shouldStop = true;
//    }
//
//    public void setShouldStop(boolean shouldStop) {
//        this.shouldStop = shouldStop;
//    }
//
//    public boolean getShouldStop() {
//        return shouldStop;
//    }
//}

//resume
//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(myThread) {
//                    while (suspended) {
//                    	try {
//                    		myThread.wait();
//                    	} catch (InterruptedException e) {
//                    		e.printStackTrace();
//                    	}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//            try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        	} catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (myThread) {
//			myThread.notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}

//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(myThread) {
//                    while (suspended) {
//                    	try {
//                    		myThread.wait();
//                    	} catch (InterruptedException e) {
//                    		e.printStackTrace();
//                    	}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//            try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        	} catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (myThread) {
//			myThread.notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}

// ******* end of plab code ******************



/**
 *  *****************************************************
 */

// ******************* old code *********** //

//Ex_01
//public class ThreadObjectWaitNotify extends Thread {
//    private volatile boolean stop = false;
//
//    public void setStop(boolean stop) {
//        this.stop = stop;
//    }
//
//    public boolean getStop() {
//        return this.stop;
//    }
//
//    @Override
//    public void run() {
//        while(!stop) {
//            // keep doing what this thread should do.
//            System.out.println("Thread is Running");
//
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadObjectWaitNotify threadStop = new ThreadObjectWaitNotify();
//        threadStop.start();
//
//        try {
//            Thread.sleep(9000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        System.out.println("Stop the Thread");
//        threadStop.setStop(true);
//    }
//}



//Ex_02
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadObjectWaitNotify extends Thread {
//
//	private Thread myThread;
//	private volatile boolean stop = false;
//	
//	@Override
//	public void run() {
//		try {
//			while (!stop) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	public void stopThread() {
//		stop = true;
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadObjectWaitNotify legacyThread = new ThreadObjectWaitNotify();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Start the Thread");
//		legacyThread.start();
//		
//		System.out.println("Stop the Thread");
//		legacyThread.stopThread();
//
//	}
//
//}


//Ex_03
//public class ThreadObjectWaitNotify {
//    private volatile boolean stopRequested;
//
//    public void requestStop() {
//        stopRequested = true;
//    }
//
//    public boolean isStopRequested() {
//        return stopRequested;
//    }
//
//    public static void main(String[] args) {
//        ThreadObjectWaitNotify threadStopExample = new ThreadObjectWaitNotify();
//        Thread thread = new Thread(() -> {
//            int i = 0;
//            while (!threadStopExample.isStopRequested()) {
//                System.out.println("Thread is running: " + i++);
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.RUNNABLE) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        threadStopExample.requestStop();
//    }
//}


//Ex_04
//public class ThreadObjectWaitNotify extends Thread {
//	public volatile boolean suspended = false;
//	
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended) {
//                    	try {
//							this.wait();
//						} catch (InterruptedException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//	
//	public void suspendThread() {
//	suspended = true;
//}
//
//	public void resumeThread() {
//	suspended = false;
//	synchronized (this) {
//		this.notify();
//		}
//	}
//	 
//    public static void main(String[] args) throws Exception
//    {
// 
//    	ThreadObjectWaitNotify thread = new ThreadObjectWaitNotify();
// 
//        thread.setName("myThread");
//        thread.start();
//        System.out.println("Thread is running...");
//        
//        Thread.sleep(500);
// 
//        System.out.println("Suspending the thread...");
//        thread.suspendThread();
//
//        Thread.sleep(5000);
// 
//        System.out.println("Resuming the thread...");
// 
//        thread.resumeThread();
//    }
//}

//******

//Ex_05
//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended) {
//                    	try {
//                    		this.wait();
//                    	} catch (InterruptedException e) {
//                    		e.printStackTrace();
//                    	}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//            try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        	} catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			this.notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}

//Ex_06

//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadObjectWaitNotify extends Thread {
//
//	private Thread myThread;
//	public volatile boolean suspended = false;
//	
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				synchronized(this) {
//                  while (suspended)
//                	  this.wait();
//              }
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	public void suspendThread() {
//	suspended = true;
//}
//
//	public void resumeThread() {
//	suspended = false;
//	synchronized (this) {
//		this.notify();
//		}
//	}
//
//	
//	public static void main(String[] args) throws IOException {
//
//		ThreadObjectWaitNotify legacyThread = new ThreadObjectWaitNotify();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Start the Thread");
//		legacyThread.start();
//		
//		System.out.println("Suspend the Thread");
//		legacyThread.suspendThread();
//		
//		System.out.println("Resume the Thread");
//		legacyThread.resumeThread();
//
//
//	}
//
//}


/*
 * 
 * 
 * 
 * 
 *  **********
 */

//public class ThreadObjectWaitNotify {
//    private final Object lock = new Object();
//    private boolean isPaused = false;
//    private boolean isStopped = false;
//
//
//    public void run() {
////        Thread thisThread = Thread.currentThread();
//        while (!isStopped) {
//            try {
//                Thread.sleep(30000);
//
//                synchronized(this) {
//                    while (isPaused)
//                        wait();
//                }
//            } catch (InterruptedException e){
//            }
//        }
//    }
//
// 
//
//    public void pauseTask() {
//        synchronized (lock) {
//            isPaused = true;  
//        }
//    }
//
//    // Method to resume the thread
//    public void resumeTask() {
//        synchronized (lock) {
//            isPaused = false;  
//            lock.notify();  
//        }
//    }
//
//    // Method to stop the thread
//    public void stopTask() {
//        synchronized (lock) {
//            isStopped = true;  
//            lock.notify();  
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadObjectWaitNotify threadControl = new ThreadObjectWaitNotify();
//
//        // Start the worker thread
//        Thread workerThread = new Thread();
//        workerThread.start();
//
//        try {
//            Thread.sleep(3000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Pause the thread
//        System.out.println("Pausing the thread...");
//        threadControl.pauseTask();
//
//        try {
//            Thread.sleep(3000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Resume the thread
//        System.out.println("Resuming the thread...");
//        threadControl.resumeTask();
//
//        try {
//            Thread.sleep(3000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Stop the thread
//        System.out.println("Stopping the thread...");
//        threadControl.stopTask();
//
//        try {
//            workerThread.join();  // Wait for the worker thread to finish
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//    }
//}


//DetectThread_01
//public class ThreadObjectWaitNotify {
//    private static Object lock = new Object();
//    private static boolean suspended = false;
//
//    public static void main(String[] args) throws InterruptedException {
//        Thread thread = new Thread(() -> {
//            while (true) {
//                synchronized (lock) {
//                    while (suspended) {
//                        try {
//                            lock.wait();
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    System.out.println("Thread is running");
//                }
//            }
//        });
//        thread.start();
//
//        Thread.sleep(1000);
//        System.out.println("Suspending thread...");
//        Thread.sleep(5000);
//        synchronized (lock) {
//            suspended = true;
//        }
//
//        Thread.sleep(1000);
//        System.out.println("Resuming thread...");
//        synchronized (lock) {
//            suspended = false;
//            lock.notify();
//        }
//    }
//}












//DetectThreadStop_02

//public class ThreadObjectWaitNotify {
//    public static void main(String[] args) throws InterruptedException {
//        Thread thread = new Thread(() -> {
//            while (true) {
//                System.out.println("Thread running...");
//                try {
//                    Thread.sleep(1000);
//                } catch (InterruptedException e) {
//                    System.out.println("Thread interrupted!");
//                    break;
//                }
//            }
//        });
//
//        thread.start();
//        Thread.sleep(2000);
//        thread.interrupt();
//    }
//}



//DetectThread_03

//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadObjectWaitNotify extends Thread {
//
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadObjectWaitNotify legacyThread = new ThreadObjectWaitNotify();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		legacyThread.interrupt();
//
//	}
//
//}


//DetectThreadStop_04

//public class ThreadObjectWaitNotify extends Thread {
//
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//	}
//
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Thread stopped abruptly.");
//		
//		threadExample.blinker.interrupt();
//	}
//}



//DetectThreadStop_05

//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//		try {
//			synchronized(blinker) {
//                while (suspended)
//                	blinker.wait();
//            }
//		} catch (InterruptedException e) {
//			System.out.println("Thread stopped due to InterruptedException");
//		}
//	}
//
//	public void suspendThread() {
//		suspended = true;
////		synchronized (blinker) {
////			try {
////				blinker.wait();
////			} catch (InterruptedException e) {
////				e.printStackTrace();
////			}
////		}
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (blinker) {
//			blinker.notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//	}
//}


//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//		while (suspended) {
//			synchronized (blinker) {
//				try {
//					blinker.wait();
//				} catch (InterruptedException e) {
//					Thread.currentThread().interrupt();
//				}
//			}
//		}
//	}
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (blinker) {
//			blinker.notify();
//		}
//	}
//	
//	public void stopThread() {
//		suspended = false;
//		blinker.interrupt();
//	}
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Thread stopped abruptly.");
//		
//		threadExample.stopThread();
//	}
//}

//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended) {
//                    	try {
//                    		this.wait();
//                    	} catch (InterruptedException e) {
//                    		Thread.currentThread().interrupt();
//                    	}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (blinker) {
//			notify();
//		}
//	}
//	
//	public void Thread() {
//		suspended = false;
//		synchronized (blinker) {
//			notify();
//		}
//	}
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//		
//
//	}
//}

//DetectThread_06

//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended) {
//                    	try {
//                    		this.wait();
//                    	} catch (InterruptedException e) {
//                    		Thread.currentThread().interrupt();
//                    	}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (blinker) {
//			blinker.notify();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}

//public class ThreadObjectWaitNotify extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended) {
//                    	try {
//                    		this.wait();
//                    	} catch (InterruptedException e) {
//                    		Thread.currentThread().interrupt();
//                    	}
//                    }
//                }
//            } catch (InterruptedException e){
//            }
//
//			try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        } catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//		synchronized(this) {
//			blinker.notify();
//		}
//	}
//
//	public void resumeThread() {
//		suspended = false;
//	}
//	
//	public void stopThread() {
//		suspended = false;
//		blinker.interrupt();
//	}
//
//	public static void main(String[] args) {
//
//		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();
//
//		threadExample.start();
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Thread stopped abruptly.");
//		
//		threadExample.stopThread();
//	}
//}

