package com.ibm.test;

import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectInputStreamGetField {

	private void readObject(ObjectInputStream.GetField fields, String attrName) throws IOException {
	    try {
	        Foo foo = (Foo) fields.get(attrName, null);

	        if (foo == null) {
	            foo = new Foo();
	        }

	        int size = fields.get("size", 0);

	        for (int i = 0; i < size; i++) {
	            System.out.println(i);
	        }
	    } catch (ClassNotFoundException e) {
	        System.err.println("Error: Class not found");
	    }
	}
	
private void readObject2(ObjectInputStream.GetField fields, String attrName) throws IOException {
		
		try {
			Foo foo = (Foo) fields.get(attrName, null);
			
			if (foo == null) {
				foo = new Foo();
			}
			
			int size = fields.get("size", 0);

			for (int i = 0; i < size; i++) {
				System.out.println(i);
			}
		} catch (ClassNotFoundException e) {
			System.err.println("Error: Class not found");
		}
	}
}
