package com.ibm.test;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.LogManager;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class CustomLogManager2 extends LogManager {

    private final PropertyChangeSupport support;

    public CustomLogManager2() {
        super();
        support = new PropertyChangeSupport(this);
        System.out.println("CustomLogManager initialized.");
    }

    @Override
    public void readConfiguration() throws IOException, SecurityException {
        super.readConfiguration();
        support.firePropertyChange("configReload", null, null);

        Logger logger = Logger.getLogger(CustomLogManager2.class.getName());
        logger.info("Logging configuration has been reloaded.");
    }

    public void addConfigurationListener(PropertyChangeListener listener) {
        support.addPropertyChangeListener(listener);
    }

    // ***************** working ****************
//    public static void main(String[] args) {
//        System.setProperty("java.util.logging.manager", CustomLogManager2.class.getName());
//
//        CustomLogManager2 logManager =  new CustomLogManager2();
//
//        logManager.addConfigurationListener(evt -> {
//            Logger logger = Logger.getLogger(CustomLogManager2.class.getName());
//            logger.info("********* Custom PropertyChangeListener detected a configuration reload.");
//        });
//        try {
//            logManager.readConfiguration();
//        } catch (IOException | SecurityException e) {
//            e.printStackTrace();
//        }
//        Logger logger = Logger.getLogger(CustomLogManager2.class.getName());
//        logger.info("This is a log message after the configuration reload.");
//    }
    
    public static void main(String[] args) {
        System.setProperty("java.util.logging.manager", CustomLogManager2.class.getName());

        CustomLogManager2 logManager =  new CustomLogManager2();
        Logger logger = Logger.getLogger(CustomLogManager2.class.getName());
        logger.setLevel(Level.FINE);
        System.out.println("******************log level and logger name " +logger.getLevel() + logger.getName());
 
        logManager.addConfigurationListener(evt -> {
        	Logger logger2 = Logger.getLogger(CustomLogManager2.class.getName());
            logger2.info("********* Custom PropertyChangeListener detected a configuration reload.");
            System.out.println("******************log level" + logger2.getLevel());
        });
        try {
        	logger.info("********* readConfiguration");
        	logger.setLevel(Level.INFO);
            logManager.readConfiguration();
        } catch (IOException | SecurityException e) {
            e.printStackTrace();
        }
//        logger.info("This is a log message after the configuration reload.");
    }
}

