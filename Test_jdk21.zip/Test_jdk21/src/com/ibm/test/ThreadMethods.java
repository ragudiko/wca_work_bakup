package com.ibm.test;

//DetectThread_01
/*
//* The example shows the better and modern approach for suspending, resuming and stopping thread.
//*/
//import java.util.concurrent.locks.ReentrantLock;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.Condition;
//
//public class ThreadMethods extends Thread{
//	
//	private Lock lock = new ReentrantLock();
//	private Condition condition = lock.newCondition();
//	private boolean suspended = false;
//	private// boolean stopped = false;
//	
//	@Override
//	public void run() {
//		try {
//			int result = 0;
//			for (int i = 1; i <= 100; i++) {
//				result += i;
//				if (i % 100 == 0) {
//					System.out.println("Current result: " + result + " i: " + i);
//				}
//			}
//		} catch (ArithmeticException e) {
//			System.out.println("Thread stopped due to arithmetic error.");
//		}
//	}
//	
//	public void resumeThread() {
//		lock.lock();
//		try {
//			suspended = false;
//			condition.signal();
//		} finally {
//			lock.unlock();
//		}
//	}
//	
//	public void pauseThread() {
//		lock.lock();
//		try {
//			while (suspended) {
//				try {
//					condition.await();
//				} catch (InterruptedException e) {
//					Thread.currentThread().interrupt();
//				}
//			}
//		} finally {
//			lock.unlock();
//		}
//	}
//	
//	public void stopThread() {
//		stopped = true;
//	}
//	
//    public static void main(String[] args) {
//    	
//    	ThreadMethods myThread = new ThreadMethods();
//
//        myThread.start();
//
//        // Let the thread run for some time
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//        System.out.println("Suspending the thread...");
//        myThread.pauseThread();
//
//        System.out.println("Resuming the thread...");
//        myThread.resumeThread();
//
//		myThread.stopThread();
//
//		System.out.println("Thread stopped abruptly.");
//    }
//}


//DetectThreadStop_02
///**
// * The example shows the better and modern approach for suspending, resuming and stopping thread.
// */
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.ReentrantLock;
//
//public class ThreadMethods extends Thread {
//
//	private Lock lock = new ReentrantLock();
//	private Condition condition = lock.newCondition();
//	private boolean suspended = false;
//	private boolean stopped = false;
//
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during database operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public void suspendMe() {
//		lock.lock();
//		try {
//			while (suspended) {
//				try {
//					condition.await();
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//			}
//			suspended = true;
//		} finally {
//			lock.unlock();
//		}
//	}
//
//	public void resumeMe() {
//		lock.lock();
//		try {
//			suspended = false;
//			condition.signalAll();
//		} finally {
//			lock.unlock();
//		}
//	}
//
//	public void stopMe() {
//		stopped = true;
//		this.interrupt();
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadMethods modernThread = new ThreadMethods();
//		modernThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		System.out.println("Suspending the thread...");
//		modernThread.suspendMe();
//
//		System.out.println("Resuming the thread...");
//		modernThread.resumeMe();
//
//		modernThread.stopMe();
//
//		System.out.println("Thread stopped abruptly.");
//
//	}
//
//}

//DetectThreadStop_03
///**
// * The example shows the better and modern approach for suspending, resuming and stopping thread.
// */
//import java.util.concurrent.locks.ReentrantLock;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.Condition;
//
//public class ThreadMethods extends Thread {
//    private boolean isPaused = false;
//    private Lock lock = new ReentrantLock();
//    private Condition condition = lock.newCondition();
//
//    @Override
//    public void run() {
//        try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        } catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//    }
//
//    public void resumeThread() {
//        lock.lock();
//        try {
//            isPaused = false;
//            condition.signalAll();
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public void pauseThread() {
//        lock.lock();
//        try {
//            isPaused = true;
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public void stopThread() {
//        lock.lock();
//        try {
//            isPaused = true;
//            condition.signalAll();
//        } finally {
//            lock.unlock();
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadMethods modernThread = new ThreadMethods();
//        modernThread.start();
//
//        try {
//            Thread.sleep(3000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        System.out.println("Suspending the thread...");
//        modernThread.pauseThread();
//
//        System.out.println("Resuming the thread...");
//        modernThread.resumeThread();
//
//        modernThread.stopThread();
//
//        System.out.println("Thread stopped abruptly.");
//    }
//}


/**
 * The example shows the better and modern approach for suspending, resuming and stopping thread.
 */
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.Condition;

public class ThreadMethods {
    private static class MyThread extends Thread {
        private final Lock lock = new ReentrantLock();
        private final Condition condition = lock.newCondition();
        private boolean suspended = false;

        @Override
        public void run() {
            try {
                int result = 0;
                for (int i = 1; i <= 100; i++) {
                    lock.lock();
                    try {
                        while (suspended) {
                            condition.await();
                        }
                    } finally {
                        lock.unlock();
                    }
                    result += i;
                    if (i % 100 == 0) {
                        System.out.println("Current result: " + result + " i: " + i);
                    }
                }
            } catch (ArithmeticException e) {
                System.out.println("Thread stopped due to arithmetic error.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void resumeThread() {
            lock.lock();
            try {
                suspended = false;
                condition.signal();
            } finally {
                lock.unlock();
            }
        }

        public void pauseThread() {
            lock.lock();
            try {
                suspended = true;
            } finally {
                lock.unlock();
            }
        }

        public void stopThread() {
            interrupt();
        }
    }

    public static void main(String[] args) {
        MyThread modernThread = new MyThread();
        modernThread.start();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Suspending the thread...");
        modernThread.pauseThread();

        System.out.println("Resuming the thread...");
        modernThread.resumeThread();

        modernThread.stopThread();

        System.out.println("Thread stopped abruptly.");
    }
}