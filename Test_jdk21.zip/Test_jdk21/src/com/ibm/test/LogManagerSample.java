package com.ibm.test;

import java.io.IOException;
import java.util.logging.LogManager;

//import java.io.IOException;

//import java.io.IOException;
//import java.util.logging.LogManager;

//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.util.logging.LogManager;
//
////import java.io.IOException;
////import java.util.logging.LogManager;
////
////public class LogManagerSample {
////
////	public static void main(String[] args) {
////		final var logManager = LogManager.getLogManager();
////
////		final Runnable listener = () -> {
////			System.out.println("Listener OK!");
////		};
////
////		logManager.addConfigurationListener(listener);
////		try {
////			System.out.println("addConfigurationListener invoked");
////			logManager.updateConfiguration(null);
////		} catch (IOException e) {
////			e.printStackTrace();
////		}
////
////		// Result
////		// ↓
////		// Listener OK!
////
////		logManager.removeConfigurationListener(listener);
////		try {
////			System.out.println("removeConfigurationListener invoked");
////			logManager.updateConfiguration(null);
////		} catch (IOException e) {
////			e.printStackTrace();
////		}
////
////		// Result
////		// ↓
////		// <No output>
////	}
////
////}
//
////package com.ibm.test;
////import java.io.IOException;
////import java.util.logging.LogManager;
////
////public class LogManagerSample {
////    public void addPropertyChangeListener(Runnable listener) {
////        LogManager.getLogManager().addConfigurationListener(listener);
////        System.out.println("addConfigurationListener invoked");
////    }
////
////    public void removePropertyChangeListener(Runnable listener) {
////        LogManager.getLogManager().removeConfigurationListener(listener);
////        System.out.println("removeConfigurationListener invoked");
////    }
////    
////    public static void main(String[] args) throws IOException {
////    	LogManagerSample logmgr = new LogManagerSample();
////    	final Runnable listener = () -> {
////			System.out.println("Listener OK!");
////		};
////    	logmgr.addPropertyChangeListener(listener);
////    	LogManager.getLogManager().updateConfiguration(null);
////    	
////    	
////    	logmgr.removePropertyChangeListener(listener);
////    	LogManager.getLogManager().updateConfiguration(null);
////    	
////    }
////}
////package com.ibm.test;
////import java.beans.PropertyChangeEvent;
////import java.beans.PropertyChangeListener;
////import java.io.IOException;
////import java.util.logging.LogManager;
////
////public class LogManagerSample {
////
////    public static void main(String[] args) throws SecurityException, IOException {
////        // Define listener of Runnable type
////        final Runnable listener = () -> {
////            System.out.println("Listener OK!");
////        };
////
////        // Add listener
////        LogManager.getLogManager().addConfigurationListener(listener);
////        LogManager.getLogManager().readConfiguration();
////        // Remove listener
////        LogManager.getLogManager().removeConfigurationListener(listener);
////    }
////}
//
//
////import java.util.logging.LogManager;
////
////public class LogManagerSample {
////
////    // Define a class level parameter listener
////    private static Runnable listener = () -> {
////        System.out.println("Configuration has changed!");
////    };
////
////    public static void main(String[] args) throws SecurityException, IOException {
////        // Add the listener
////        LogManager.getLogManager().addConfigurationListener(listener);
////
////        // Trigger a configuration change
////        LogManager.getLogManager().readConfiguration();
////
////        // Remove the listener
////        LogManager.getLogManager().removeConfigurationListener(listener);
////    }
////}
//
//
//
//
////import java.util.logging.LogManager;
////
/////**
//// * Example of using the LogManager class to add and remove a configuration listener.
//// */
////public class LogManagerSample {
////
////    private Runnable listener;
////
////    /**
////     * Adds a configuration listener and reads the configuration.
////     */
////    public void readConfiguration() {
////        try {
////            // Create a listener that prints a message when it is triggered
////            listener = () -> System.out.println("Configuration has changed");
////
////            // Add the listener
////            LogManager.getLogManager().addConfigurationListener(listener);
////
////            // Read the configuration
////            LogManager.getLogManager().readConfiguration();
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////    }
////
////    /**
////     * Removes the configuration listener.
////     */
////    public void removeListener() {
////        if (listener != null) {
////            LogManager.getLogManager().removeConfigurationListener(listener);
////        }
////    }
////}
//
//
//
//import java.util.logging.LogManager;
//
///**
// * Example of using the LogManager class in Java.
// */
//public class LogManagerSample {
//
//    private Runnable listener;
//
//    /**
//     * Add a configuration listener.
//     */
//    public void addConfigurationListener() {
//        listener = () -> {
//            System.out.println("Configuration has changed");
//        };
//        LogManager.getLogManager().addConfigurationListener(listener);
//    }
//
//    /**
//     * Read the configuration.
//     */
//    public void readConfiguration() {
//        try {
//            LogManager.getLogManager().readConfiguration();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    /**
//     * Remove the configuration listener.
//     */
//    public void removeConfigurationListener() {
//        LogManager.getLogManager().removeConfigurationListener(listener);
//    }
//
//    /**
//     * Main method to demonstrate the use of the LogManagerExample class.
//     * @param args command line arguments
//     */
//    public static void main(String[] args) {
//        LogManagerSample example = new LogManagerSample();
//        example.addConfigurationListener();
//        example.readConfiguration();
//        example.removeConfigurationListener();
//    }
//}



//plab

//import java.util.logging.LogManager;
//
//public class LogManagerSample {
//
//    private final Runnable listener;
//
//    public LogManagerSample() {
//        this.listener = () -> System.out.println("Configuration changed");
//    }
//
//    public void addConfigurationListener() {
//        LogManager.getLogManager().addConfigurationListener(listener);
////    	LogManager lm = LogManager.getLogManager();
////    	lm.addConfigurationListener(listener);
//    }
//
//    public void readConfiguration() {
//        try {
//            LogManager.getLogManager().readConfiguration();
//        } catch (SecurityException e) {
//            System.out.println("SecurityException: " + e.getMessage());
//        } catch (IOException e) {
//			e.printStackTrace();
//		}
//    }
//
//    public void removeConfigurationListener() {
//        LogManager.getLogManager().removeConfigurationListener(listener);
//    }
//
//    public static void main(String[] args) {
//        LogManagerSample example = new LogManagerSample();
//        example.addConfigurationListener();
//        example.readConfiguration();
//        example.removeConfigurationListener();
//    }
//}

//import java.util.logging.LogManager;
//
//public class LogManagerSample {
//
//    private final Runnable listener;
//
//    public LogManagerSample() {
//        this.listener = () -> System.out.println("Configuration changed");
//    }
//
//    public void addConfigurationListener() {
//        LogManager.getLogManager().addConfigurationListener(listener);
//    }
//
//    public void readConfiguration() {
//        try {
//            LogManager.getLogManager().readConfiguration();
//        } catch (SecurityException e) {
//            System.out.println("SecurityException: " + e.getMessage());
//        } catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//    }
//
//    public void removeConfigurationListener() {
//        LogManager.getLogManager().removeConfigurationListener(listener);
//    }
//
//    public static void main(String[] args) {
//        LogManagerSample example = new LogManagerSample();
//        example.addConfigurationListener();
//        example.readConfiguration();
//        example.removeConfigurationListener();
//    }
//}

//import java.io.IOException;

public class LogManagerSample {

    public static void main(String[] args) {
        Runnable listener = () -> System.out.println("Config changed");

        try {
            LogManager.getLogManager().addConfigurationListener(listener);
            LogManager.getLogManager().readConfiguration();
            LogManager.getLogManager().removeConfigurationListener(listener);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}


