package com.ibm.test;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

public class SafePauseResumeThread implements Runnable {
    private final Lock lock = new ReentrantLock();
    private final Condition pauseCondition = lock.newCondition();
    private boolean isPaused = false;
    private Thread thread;

    public SafePauseResumeThread() {
        thread = new Thread(this);
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            lock.lock();
            try {
                while (isPaused) {
                    pauseCondition.await();  // Wait while the thread is paused
                }
                System.out.println("Thread is running...");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();  // Preserve interrupt status
                break;  // Exit the loop if interrupted
            } finally {
                lock.unlock();
            }

            try {
                Thread.sleep(1000);  // Simulate work
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();  // Handle interrupt during sleep
                break;
            }
        }
        System.out.println("Thread stopped.");
    }

    public void startThread() {
        thread.start();
    }

    public void pauseThread() {
        lock.lock();
        try {
            isPaused = true;  // Set the paused flag to true
        } finally {
            lock.unlock();
        }
    }

    public void resumeThread() {
        lock.lock();
        try {
            isPaused = false;  // Set the paused flag to false
            pauseCondition.signal();  // Resume the thread
        } finally {
            lock.unlock();
        }
    }

    public void stopThread() {
        thread.interrupt();  // Use interrupt to stop the thread
    }

    public static void main(String[] args) {
        SafePauseResumeThread safeThread = new SafePauseResumeThread();
        safeThread.startThread();

        try {
            Thread.sleep(3000);  // Let the thread run for 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Pausing the thread...");
        safeThread.pauseThread();  // Pause the thread

        try {
            Thread.sleep(3000);  // Let it stay paused for 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Resuming the thread...");
        safeThread.resumeThread();  // Resume the thread

        try {
            Thread.sleep(3000);  // Let the thread run for 3 more seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        safeThread.stopThread();  // Stop the thread
    }
}
