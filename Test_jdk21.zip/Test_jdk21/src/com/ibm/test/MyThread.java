package com.ibm.test;

public class MyThread extends Thread {
    @Override
    public void run() {
        while (!isInterrupted()) {
            // Do something
            ThreadUtils.pauseThread(this);
        }
    }
}