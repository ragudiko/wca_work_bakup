package com.ibm.test;


//Ex_01
//public class ThreadStopUOE2 extends Thread {
//    @Override
//    public void run() {
//        while(true) {
//            // keep doing what this thread should do.
//            System.out.println("Thread is Running");
//
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//
//        }
//    }
//
//    public static void main(String[] args) {
//    	ThreadStopUOE2 legacyThread = new ThreadStopUOE2();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(9000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        System.out.println("Stop the Thread");
//        legacyThread.stop();
//    }
//}



//Ex_02


//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopUOE2 extends Thread {
//
//	private Thread myThread;
//	
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	public void stopThread() {
//		myThread.stop();
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopUOE2 legacyThread = new ThreadStopUOE2();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Start the Thread");
//		legacyThread.start();
//		
//		System.out.println("Stop the Thread");
//		legacyThread.stopThread();
//
//	}
//
//}



//Ex_03
//public class ThreadStopUOE2 {
//    public static void main(String[] args) {
//        Thread thread = new Thread(() -> {
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        thread.stop();
//    }
//}


//Ex_04
//public class ThreadStopUOE2 extends Thread {
//	public volatile boolean suspended = false;
//	
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	Thread.currentThread().suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//	
//	public void suspendThread() {
//	suspended = true;
//}
//
//	public void resumeThread() {
//	suspended = false;
//	synchronized (this) {
//		Thread.currentThread().resume();
//		}
//	}
//	 
//    // Main Driver Method
//    public static void main(String[] args) throws Exception
//    {
// 
//        // Creating a thread
//    	ThreadStopUOE2 thread = new ThreadStopUOE2();
// 
//        thread.setName("myThread");
//        thread.start();
//        System.out.println("Thread is running...");
//        
//        Thread.sleep(500);
// 
//        System.out.println("Suspending the thread...");
//        thread.suspendThread();
//
//        Thread.sleep(5000);
// 
//        System.out.println("Resuming the thread...");
// 
//        thread.resumeThread();
//    }
//}

//Ex_05
//public class ThreadStopUOE2 extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	myThread.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        	} catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true; //suspend thread
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			myThread.resume();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE2 threadExample = new ThreadStopUOE2();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}


//Ex_06


import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class ThreadStopUOE2 extends Thread {

	private Thread myThread;
	public volatile boolean suspended = false;
	
	@Override
	public void run() {
		try {
			while (true) {
				synchronized(this) {
                  while (suspended)
                	  myThread.suspend();
              }
				ReadableByteChannel rbc = new ReadableByteChannel() {
					public int read(ByteBuffer dst) {
						dst.put((byte) 0);
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						return 1;
					}

					public boolean isOpen() {
						return true;
					}

					public void close() {
					}
				};
				Thread.sleep(1500);
				InputStream in = Channels.newInputStream(rbc);
				byte[] b = new byte[3];
				in.read(b, 0, 1);
				in.read(b, 2, 1); // throws IAE
			}
		} catch (InterruptedException e) {
			System.out.println("Thread interrupted during operation.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void start() {
		myThread = new Thread(this);
		myThread.start();
	}

	public void suspendThread() {
	suspended = true; //suspend thread
}

	public void resumeThread() {
	suspended = false;
	synchronized (this) {
		myThread.resume();
		}
	}

	
	public static void main(String[] args) throws IOException {

		ThreadStopUOE2 legacyThread = new ThreadStopUOE2();
		legacyThread.start();

		try {
			Thread.sleep(5000); // Let the thread insert some data
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Start the Thread");
		legacyThread.start();
		
		System.out.println("Suspend the Thread");
		legacyThread.suspendThread();
		
		System.out.println("Resume the Thread");
		legacyThread.resumeThread();


	}

}



/*
 * 
 * 
 * 
 * ******************************
 */

//public class ThreadStopUOE2 extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	myThread.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (myThread) {
//			myThread.resume();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE2 threadExample = new ThreadStopUOE2();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//
//	}
//}

//DetectThreadStop_02
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopUOE2 extends Thread {
//
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during database operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopUOE2 legacyThread = new ThreadStopUOE2();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		legacyThread.stop();
//
//	}
//
//}

//DetectThreadStop_03
//public class ThreadStopUOE2 extends Thread {
//	@Override
//	public void run() {
//		try {
//			int result = 0;
//			for (int i = 1; i <= 100; i++) {
//				result += i;
//				if (i % 100 == 0) {
//					System.out.println("Current result: " + result + " i: " + i);
//				}
//			}
//		} catch (ArithmeticException e) {
//			System.out.println("Thread stopped due to arithmetic error.");
//		}
//	}
//
//	public static void main(String[] args) {
//		ThreadStopUOE2 legacyThread = new ThreadStopUOE2();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Suspending the thread...");
//		legacyThread.suspend();
//
//		System.out.println("Resuming the thread...");
//		legacyThread.resume();
//
//		legacyThread.stop();
//
//		System.out.println("Thread stopped abruptly.");
//	}
//}


//DetectThread_04
//public class ThreadStopUOE2 extends Thread {
//
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//	}
//
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE2 threadExample = new ThreadStopUOE2();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Thread stopped abruptly.");
//		
//		threadExample.blinker.stop();
//	}
//}

//DetectThread_05



//public class ThreadStopUOE2 extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	blinker.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (blinker) {
//			blinker.resume();
//		}
//	}
//	
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE2 threadExample = new ThreadStopUOE2();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//		
//
//	}
//}


//DetectThread_06

//public class ThreadStopUOE2 extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//	
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	blinker.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (blinker) {
//			blinker.resume();
//		}
//	}
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE2 threadExample = new ThreadStopUOE2();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//
//	}
//}

//public class ThreadStopUOE2 extends Thread {
//
//	public volatile boolean suspended = false;
//	private Thread blinker;
//
//	public void start() {
//		blinker = new Thread(this);
//		blinker.start();
//	}
//
//	@Override
//	public void run() {
//        while (true) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	blinker.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//
//			try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        } catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//            
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//		blinker.suspend();
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		blinker.resume();
//	}
//	
//	public void stopThread() {
//		suspended = false;
//		blinker.stop();
//	}
//
//	public static void main(String[] args) {
//
//		ThreadStopUOE2 threadExample = new ThreadStopUOE2();
//
//		threadExample.start();
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Thread stopped abruptly.");
//		
//		threadExample.stopThread();
//	}
//}