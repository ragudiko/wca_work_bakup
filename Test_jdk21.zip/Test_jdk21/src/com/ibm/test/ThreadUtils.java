package com.ibm.test;

public class ThreadUtils {
    public static void resumeThread(Thread thread) {
        synchronized (thread) {
            thread.notify();
        }
    }

    public static void pauseThread(Thread thread) {
        synchronized (thread) {
            try {
                thread.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void stopThread(Thread thread) {
        thread.interrupt();
    }
}
