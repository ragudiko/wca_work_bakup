package com.ibm.test;

public class Test {
	
	public static void main(String[] args) {
		ThreadGroup group = new ThreadGroup("foo");
		//flags
		group.setDaemon(true);
		
		//flags
		group.isDaemon();
		
		//flags
		group.destroy();
				
		//flags
		group.isDestroyed();
		
	}

}
