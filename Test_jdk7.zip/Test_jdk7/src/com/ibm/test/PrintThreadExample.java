package com.ibm.test;

//public class PrintThreadExample extends Thread {
//
//	String document = "Document1"; 
//	public volatile boolean suspended = false;
//
//	public synchronized void printDocument(String document) {
//		while (true) {
//			if(suspended) {
//			synchronized (this) {
//				this.suspend();
//			}
//			}
//			else {
//			System.out.println(Thread.currentThread().getName() + " printing sample document: " + document);
//			try {
//				Thread.sleep(10000);
//			} catch (InterruptedException e) {
//				Thread.currentThread().interrupt();
//			}
//		}
//			System.out.println(Thread.currentThread().getName() + " done with printing document: " + document);
//		}
//	}
//
//	@Override
//	public void run() {
//		printDocument(document);
//	}
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			resume();
//		}
//	}
//
//	public static void main(String[] args) {
//		PrintThreadExample printerSample = new PrintThreadExample();
//
//		printerSample.start();
//
//		try {
//			Thread.sleep(2000); 
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println(" suspend the thread");
//		printerSample.suspendThread();
//
//		try {
//			Thread.sleep(5000); 
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//		System.out.println(" resume the thread");
//		printerSample.resumeThread();
//		
//	}
//}





