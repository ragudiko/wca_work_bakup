package com.ibm.test;

public class ThreadStop_OracleDoc implements Runnable{
	private volatile Thread blinker;
	private volatile boolean threadSuspended;
	
	@Override
	public void run() {
        Thread thisThread = Thread.currentThread();
        while (blinker == thisThread) {
            try {
                Thread.sleep(1);

                synchronized(this) {
                    while (threadSuspended && blinker==thisThread)
                        wait();
                }
            } catch (InterruptedException e){
            }
            //repaint();
            System.out.println("Thread is terminating gracefully.");
        }
    }

    public synchronized void stop() {
        blinker = null;
        notify();
    }
    
    public static void main(String[] args) throws InterruptedException {
		ThreadStopSample_Variable runnable = new ThreadStopSample_Variable();
		Thread thread = new Thread(runnable);
		thread.start();
		Thread.sleep(3000);
		runnable.stop();
	}
}
