package com.ibm.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.logging.*;

public class LoggingGlobalHandlerTest {
  public static void main(String[] args) throws IOException {
    System.err.println("At start-up, handlers:");
    for (Handler handler : Logger.getLogger("").getHandlers()) {
      System.err.println("... " + handler);
    }

    LogManager.getLogManager().addPropertyChangeListener(new PropertyChangeListener() {
        public void propertyChange(PropertyChangeEvent event) {
          System.err.println("During propertyChange:");
          System.err.println("... name " + Logger.getLogger("").getName() + " level: " + 
          Logger.getLogger("").getLevel()+ " getHandlers().length:" +
        		  Logger.getLogger("").getHandlers().length);
          for (Handler handler : Logger.getLogger("").getHandlers()) {
            System.err.println("... " + handler);
          }
        }
    });
    
    LogManager.getLogManager().readConfiguration();

    System.err.println("After reset, handlers:");
    for (Handler handler : Logger.getLogger("").getHandlers()) {
      System.err.println("... " + handler);
    }
  }
}
