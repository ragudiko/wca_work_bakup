package com.ibm.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class LogManager_AddProperty {

//	public static void main(String[] args) {
//		// Register for the event
//	    LogManager.getLogManager().addPropertyChangeListener(new PropertyChangeListener() {
//	      // This method is called when configuration file is reread
//	      public void propertyChange(PropertyChangeEvent evt) {
//	        String propName = evt.getPropertyName();
//	        Object oldValue = evt.getOldValue();
//	        Object newValue = evt.getOldValue();
//	        System.out.println("propName oldValue newValue" + propName +  oldValue + newValue);
//	        // All values are null
//	      }
//	    });
//
//	}
	
	public static void main(String[] args) {
		final LogManager logManager = LogManager.getLogManager();
        Logger logger = Logger.getLogger(LogManager_AddProperty.class.getName());
        logger.setLevel(Level.INFO);
        FileInputStream fis =  null;
    	try {
    		fis =  new FileInputStream("src/logging.properties");
            LogManager.getLogManager().readConfiguration(fis);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 

        // Add a PropertyChangeListener to the LogManager
        logManager.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("LogManager configuration changed:");
                System.out.println("Property: " + evt.getPropertyName());
                System.out.println("Old Value: " + evt.getOldValue());
                System.out.println("New Value: " + evt.getNewValue());
//                try {
//                	FileInputStream fis =  new FileInputStream("src/logging.properties");
//                	LogManager.getLogManager().readConfiguration(fis);
//                } catch(IOException e) {
//                	e.printStackTrace();
//                }
             // You can access the logger levels here, after configuration is reloaded
                Logger updatedLogger = Logger.getLogger(LogManager_AddProperty.class.getName());
                System.out.println("Logger level: " + updatedLogger.getLevel());
            }
        });
        logManager.addPropertyChangeListener(new LogManagerChannel());

        // Log an initial message
        logger.info("Initial log message");
//        System.out.println("Initial log message");

        // Simulate reading a new configuration, triggering the PropertyChangeListener
        try {
//        	logger.setLevel(Level.WARNING);
//        	FileInputStream fis =  new FileInputStream("src/logging.properties");
            LogManager.getLogManager().readConfiguration(fis);
//            logManager.readConfiguration(); // This will typically trigger a property change event
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Log another message after configuration change
        logger.info("Log message after configuration change");
    }

}
