package com.ibm.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class LogManagerChannel implements PropertyChangeListener {

    private String level;

    public void setLevel(String level) {
		this.level = level;
	}

	public String getLevel() {
		return level;
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		this.setLevel((String) evt.getNewValue());
		System.out.println("LogManagerChannel propertyChange " + evt.getNewValue());
	}

}