package com.ibm.test;

//import java.beans.PropertyChangeEvent;
//import java.beans.PropertyChangeListener;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.logging.ConsoleHandler;
//import java.util.logging.Level;
//import java.util.logging.LogManager;
//import java.util.logging.Logger;
//
//public class LogManagerExample {
//
//    public static void main(String[] args) {
//        final Logger logger = Logger.getLogger(LogManagerExample.class.getName());
//        LogManager logManager = LogManager.getLogManager();
////        System.out.println(" java.util.logging.ConsoleHandler.level " +logManager.getProperty("java.util.logging.ConsoleHandler.level"));
////        logManager.getLogger(logger.getName()).setLevel(Level.SEVERE);
////        System.out.println(" java.util.logging.ConsoleHandler.level " +logManager.getProperty("java.util.logging.ConsoleHandler.level"));
//        
//        try {
//            LogManager.getLogManager().readConfiguration(new FileInputStream("src/logging.properties"));
//        } catch (SecurityException | IOException e1) {
//            e1.printStackTrace();
//        }
//        logger.setLevel(Level.FINE);
//        logger.addHandler(new ConsoleHandler());
//        
//        // Adding a PropertyChangeListener to LogManager
//        logManager.addPropertyChangeListener(new PropertyChangeListener() {
//            @Override
//            public void propertyChange(PropertyChangeEvent evt) {
//                System.out.println("Logging configuration changed.");
//                System.out.println("Property name: " + evt.getPropertyName());
//                System.out.println("Old value: " + evt.getOldValue());
//                System.out.println("New value: " + evt.getNewValue());
//
//                // You can access the logger levels here, after configuration is reloaded
//                Logger updatedLogger = Logger.getLogger(logger.getName());
//                System.out.println("Updated Logger level: " + updatedLogger.getLevel());
//            }
//        });
//
//        // Simulate reading configuration
//        try (InputStream configFile = new FileInputStream("src/logging.properties")) {
//            logManager.readConfiguration(configFile);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // Log a message to test
//        logger.info("This is a log message.");
//
//        // The property change listener should be triggered if the configuration changes.
//    }
//}


