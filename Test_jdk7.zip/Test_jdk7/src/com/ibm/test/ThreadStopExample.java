package com.ibm.test;


public class ThreadStopExample extends Thread {

	String document = "Document1"; 

	public synchronized void printDocument(String document) {
		while (true) {
			System.out.println(Thread.currentThread().getName() + " printing sample document: " + document);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
			System.out.println(Thread.currentThread().getName() + " done with printing document: " + document);
		}
	}

	@Override
	public void run() {
		printDocument(document);
	}



	public static void main(String[] args) {
		ThreadStopExample printerSample = new ThreadStopExample();

		printerSample.start();

		try {
			Thread.sleep(5000); 
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		System.out.println(" stop the thread");
		printerSample.stop();
		
	}
}




//prompt lab
//01
//public class ThreadStopExample {
//    private volatile boolean shouldStop = false;
//
//    public static void main(String[] args) {
//        Thread thread = new Thread(() -> {
//            while (!shouldStop) {
//                try {
//                    Thread.sleep(1000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        shouldStop = true;
//    }
//}

//02
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopExample extends Thread {
//
//	private volatile boolean shouldStop = false;
//
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				if (shouldStop) {
//					System.out.println("Thread interrupted during database operation.");
//					break;
//				}
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during database operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public void setShouldStop(boolean shouldStop) {
//		this.shouldStop = shouldStop;
//	}
//
//	public boolean getShouldStop() {
//		return shouldStop;
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopExample legacyThread = new ThreadStopExample();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		legacyThread.setShouldStop(true);
//
//	}
//
//}

//03
//public class ThreadStopExample extends Thread {
//    private volatile boolean shouldStop = false;
//
//    @Override
//    public void run() {
//        try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//                if (shouldStop) {
//                    System.out.println("Thread stopped due to shouldStop flag being set.");
//                    break;
//                }
//            }
//        } catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//    }
//
//    public void setShouldStop(boolean shouldStop) {
//        this.shouldStop = shouldStop;
//    }
//
//    public boolean getShouldStop() {
//        return shouldStop;
//    }
//
//    public static void main(String[] args) {
//        ThreadStopExample legacyThread = new ThreadStopExample();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(3000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        legacyThread.setShouldStop(true);
//    }
//}

//public class ThreadStopExample {
//    public static void main(String[] args) throws InterruptedException {
//        Thread thread = new Thread(() -> {
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//                System.out.println("Thread interrupted");
//            }
//        });
//
//        thread.start();
//        Thread.sleep(500);
//        thread.interrupt();
//    }
//}
//Thread interrupted

/* throws java.lang.UnsupportedOperationException*/
//public class ThreadStopExample {
//    public static void main(String[] args) {
//        Thread thread = new Thread(() -> {
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//            	System.out.println("Thread interrupted");
//                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//            	System.out.println("Thread interrupted");
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        thread.stop(new RuntimeException("Stopping the thread"));
//    }
//}

//public class ThreadStopExample {
//    public static void main(String[] args) {
//        Thread thread = new Thread(() -> {
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//            	System.out.println("Thread interrupted");
//                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//            	System.out.println("Thread interrupted");
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        thread.stop();
//        thread.isInterrupted();
//    }
//}

//public class ThreadStopExample {
//    public static void main(String[] args) {
//        Thread thread = new Thread(() -> {
//            try {
//                Thread.sleep(10000);
//            } catch (InterruptedException e) {
//            	System.out.println("1 Thread interrupted");
////                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//            	System.out.println("2 Thread interrupted");
//                //e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        // thread.stop(new RuntimeException("Stopping the thread"));
//        thread.interrupt();
//    }
//}

//public class ThreadStopExample {
//    private volatile boolean stopRequested;
//
//    public void requestStop() {
//        stopRequested = true;
//    }
//
//    public boolean isStopRequested() {
//        return stopRequested;
//    }
//
//    public static void main(String[] args) {
//        ThreadStopExample threadStopExample = new ThreadStopExample();
//
//        Thread thread = new Thread(() -> {
//            try {
//                while (!threadStopExample.isStopRequested()) {
//                    Thread.sleep(1000);
//                }
//            } catch (InterruptedException e) {
//            	System.out.println("1 Thread interrupted");
//                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//        System.out.println("Thread.State: " + thread.getState());
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//            	System.out.println("2 Thread interrupted");
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        threadStopExample.requestStop();
//        System.out.println("3 Thread interrupted");
//    }
//}

///**
// * The sample show cases using volatile flag to indicate when thread should stop. There is an alternative solution which proposes using of Thread.interrupt() in place of Thread.stop(Throwable t).
// */
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopExample extends Thread {
//
//	private volatile boolean stopRequested;
//
//	public void requestStop() {
//		stopRequested = true;
//	}
//
//	public boolean isStopRequested() {
//		return stopRequested;
//	}
//
//	@Override
//	public void run() {
//		try {
//			while (!stopRequested) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during database operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopExample legacyThread = new ThreadStopExample();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		// Dangerous method: Thread.stop(Throwable t)
//		legacyThread.requestStop();
//
//	}
//
//}

//ThreadStopThrowable_01
//public class ThreadStopExample {
//    private volatile boolean stopRequested;
//
//    public void requestStop() {
//        this.stopRequested = true;
//    }
//
//    public boolean isStopRequested() {
//        return this.stopRequested;
//    }
//
//    public static void main(String[] args) {
//        ThreadStopExample threadStopExample = new ThreadStopExample();
//        Thread thread = new Thread(() -> {
//            try {
//                int i = 0;
//                while (!threadStopExample.isStopRequested()) {
//                    System.out.println("Thread is running: " + i++);
//                    Thread.sleep(1000);
//                }
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        threadStopExample.requestStop();
//    }
//}



//ThreadStopThrowable_02
//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopExample extends Thread {
//
//	private volatile boolean stop = false;
//
//	public void setStop(boolean stop) {
//		this.stop = stop;
//	}
//
//	public boolean getStop() {
//		return stop;
//	}
//
//	@Override
//	public void run() {
//		try {
//			while (!stop) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during database operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopExample legacyThread = new ThreadStopExample();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		legacyThread.setStop(true);
//
//	}
//
//}



//ThreadStopThrowable_03
//public class ThreadStopExample extends Thread {
//    private volatile boolean stopRequested;
//
//    public void requestStop() {
//        stopRequested = true;
//    }
//
//    public boolean isStopRequested() {
//        return stopRequested;
//    }
//
//    @Override
//    public void run() {
//        try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//                if (stopRequested) {
//                    throw new InterruptedException("Stop requested");
//                }
//            }
//        } catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        } catch (InterruptedException e) {
//            System.out.println("Thread stopped due to stop request.");
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopExample legacyThread = new ThreadStopExample();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(3000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        legacyThread.requestStop();
//    }
//}






///**
// * The sample show cases using volatile flag to indicate when thread should stop. There is an alternative solution which proposes using of Thread.interrupt() in place of Thread.stop(Throwable t).
// */
//public class ThreadStopExample extends Thread {
//    private volatile boolean stop = false;
//
//    @Override
//    public void run() {
//        try {
//            int result = 0;
//            for (int i = 1; i <= 1000; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//                if (stop) {
//                    throw new InterruptedException("Forcing the thread to stop.");
//                }
//            }
//        } catch (InterruptedException e) {
//            System.out.println("Thread stopped due to InterruptedException.");
//        }
//    }
//
//    public void setStop(boolean stop) {
//        this.stop = stop;
//    }
//
//    public boolean isStop() {
//        return stop;
//    }
//
//    public static void main(String[] args) {
//        ThreadStopExample legacyThread = new ThreadStopExample();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(3000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        legacyThread.setStop(true);
//    }
//}




///**
// * The sample show cases using volatile flag to indicate when thread should stop. There is an alternative solution which proposes using of Thread.interrupt() in place of Thread.stop(Throwable t).
// */
//public class ThreadStopExample {
//    private volatile boolean stopRequested;
//
//    public void requestStop() {
//        this.stopRequested = true;
//    }
//
//    public boolean isStopRequested() {
//        return this.stopRequested;
//    }
//
//    public static void main(String[] args) {
//        ThreadStopExample threadStopExample = new ThreadStopExample();
//        Thread thread = new Thread(() -> {
//            try {
//                while (!threadStopExample.isStopRequested()) {
//                    Thread.sleep(1000);
//                }
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        });
//
//        thread.start();
//
//        // Wait for the thread to start
//        while (thread.getState() != Thread.State.TIMED_WAITING) {
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
//        // Stop the thread
//        threadStopExample.requestStop();
//    }
//}
//
//


//ICL input
//public class ThreadStopExample extends Thread {
//	
//	public volatile boolean suspended = false;
//	private boolean isStopped = false;
//
//	public void run() {
//        synchronized (this) {
//            while (!isStopped) {
//                if (suspended) {
//                    System.out.println("Thread is suspended...");
//					this.suspend();
//                }
//                
//                System.out.println("Thread is running...");
//                try {
//                    Thread.sleep(1000);
//                } catch (InterruptedException e) {
//                    Thread.currentThread().interrupt();
//                }
//            }
//        }
//        System.out.println("Thread has stopped.");
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			this.resume();
//		}
//	}
//
//	public void stopThread() {
//		synchronized (this) {
//			isStopped = true;
//			this.notify(); // Wake up the thread to allow it to stop
//		}
//	}
//
//    public static void main(String[] args) {
//        ThreadStopExample thread = new ThreadStopExample();
//
//        thread.start();
//
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Suspending the thread...");
//        thread.suspendThread();
//
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Resuming the thread...");
//        thread.resumeThread();
//
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Stopping the thread...");
//        thread.stopThread();
//
//        System.out.println("Main thread finished.");
//    }
//}


//Before



//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopExample extends Thread {
//
//	private Thread myThread;
//	public volatile boolean suspended = false;
//	
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				if(suspended) {
//					synchronized (this) {
//						this.suspend();
//					}
//				}
//					
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			this.resume();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopExample legacyThread = new ThreadStopExample();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Start the Thread");
//		legacyThread.start();
//		
//		System.out.println("Suspend the Thread");
//		legacyThread.suspendThread();
//		
//		System.out.println("Resume the Thread");
//		legacyThread.resumeThread();
//
//	}
//
//}





//Before
//public class ThreadStopExample extends Thread {
//
//	public volatile boolean suspended = false;
//	private boolean isStoped = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (!isStoped) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	this.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        	} catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			this.resume();
//		}
//	}
//	
//	public void stopThread() {
//		synchronized (this) {
//			isStoped = true;
//			this.notify();  // Wake up the thread to allow it to stop
//		}
//	}
//
//	public static void main(String[] args) {
//
//		ThreadStopExample threadExample = new ThreadStopExample();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		System.out.println("Stopping the thread...");
//		threadExample.stopThread();
//
//	}
//}

//public class ThreadStopExample extends Thread {
//
//	public volatile boolean suspended = false;
//	private boolean isStoped = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (!isStoped) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	suspend();
//                }
//            } catch (InterruptedException e){
//            }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			resume();
//		}
//	}
//	
//	public void stopThread() {
//		isStoped = true;
//		synchronized (this) {
//			stop();
//		}
//	}
//
//	public static void main(String[] args) {
//
//		ThreadStopExample threadExample = new ThreadStopExample();
//
//		threadExample.start();
//		System.out.println("Thread is running...");
//
//		// Let the thread run for some time
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Suspending the thread...");
//
//		threadExample.suspendThread();
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println("Resuming the thread...");
//
//		threadExample.resumeThread();
//		
//		//Stop the thread
//		System.out.println("Stopping the thread...");
//		threadExample.stop();
//
//	}
//}

//public class ThreadStopExample extends Thread {
//
//	public volatile boolean suspended = false;
//	public volatile boolean isStoped = false;
//	private Thread myThread;
//
//	public void start() {
//		myThread = new Thread(this);
//		myThread.start();
//	}
//
//	@Override
//	public void run() {
//        while (!stopped) {
//            try {
//                Thread.sleep(1000);
//
//                synchronized(this) {
//                    while (suspended)
//                    	myThread.suspend();
//                }
//            } catch (InterruptedException e){
//            }
//            try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        	} catch (ArithmeticException e) {
//            System.out.println("Thread stopped due to arithmetic error.");
//        }
//        }
//    }
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			myThread.resume();
//		}
//	}
//	
//	public void stopThread() {
//        synchronized (this) {
//            stopped = true;
//            notify();  // Wake up the thread to allow it to stop
//        }
//    }
//}
