package com.ibm.test;

class PrinterScanner1 {
   
    public synchronized void printDocument(String document) {
        System.out.println(Thread.currentThread().getName() + " is printing document: " + document);
        try {
            Thread.sleep(2000);  // Simulate the time taken to print a document
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(Thread.currentThread().getName() + " finished printing document: " + document);
    }


}

class PrintJob1 implements Runnable {
    private final PrinterScanner1 printerScanner;
    private final String document;
    public volatile boolean suspended = false;

    public PrintJob1(PrinterScanner1 printerScanner, String document) {
        this.printerScanner = printerScanner;
        this.document = document;
    }

    @Override
    public void run() {
        printerScanner.printDocument(document);
    }
}



public class PrintScannerSample {
		
    public static void main(String[] args) {
        PrinterScanner1 printerScanner = new PrinterScanner1();

        Thread printThread1 = new Thread(new PrintJob1(printerScanner, "Document1.pdf"), "PrintJob1");

        printThread1.start();
        
        try {
            Thread.sleep(2000);  // Simulate the time taken to print a document
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.println(" suspend the thread");
        printThread1.suspend();
        
        try {
            Thread.sleep(2000);  // Simulate the time taken to print a document
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(" resume the thread");
        printThread1.resume();

    }
}
