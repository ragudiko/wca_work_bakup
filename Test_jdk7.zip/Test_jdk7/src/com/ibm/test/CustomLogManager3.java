package com.ibm.test;

//Assisted by WCA@IBM
//Latest GenAI contribution: ibm/granite-20b-code-instruct-v2
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.ConsoleHandler;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class CustomLogManager3 extends LogManager {

 private List<PropertyChangeListener> listeners = new ArrayList<>();

 @Override
 public void addPropertyChangeListener(PropertyChangeListener listener) {
     listeners.add(listener);
 }

 @Override
 public void removePropertyChangeListener(PropertyChangeListener listener) {
     listeners.remove(listener);
 }

 public void firePropertyChangeEvent(String propertyName, Object oldValue, Object newValue) {
     PropertyChangeEvent event = new PropertyChangeEvent(this, propertyName, oldValue, newValue);
     for (PropertyChangeListener listener : listeners) {
         listener.propertyChange(event);
     }
 }
 
 public static void main(String a[]) {
	// Assisted by WCA@IBM
	// Latest GenAI contribution: ibm/granite-20b-code-instruct-v2
	CustomLogManager3 logManager = new CustomLogManager3();
	Logger logger = Logger.getLogger("MyLogger");
	logger.addHandler(new ConsoleHandler());
	logManager.addPropertyChangeListener((event) -> {
	    System.out.println("Property changed: " + event.getPropertyName());
	});
	logManager.firePropertyChangeEvent("handlers", null, logger.getHandlers());

 }
}

