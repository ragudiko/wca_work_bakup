package com.ibm.test;

//public class ThreadObjectWaitNotify {
//    private final Object lock = new Object();
//    private boolean isPaused = false;
//    private boolean isStopped = false;
//
//    // Worker thread logic
//    public void runTask() {
//        synchronized (lock) {
//            while (!isStopped) {
//                while (isPaused) {
//                    try {
//                        lock.wait();  // Pause the thread by waiting on the lock object
//                    } catch (InterruptedException e) {
//                        Thread.currentThread().interrupt();
//                        return;  // Exit the method if the thread is interrupted
//                    }
//                }
//                // Simulate some work
//                System.out.println("Thread is running...");
//                try {
//                    Thread.sleep(1000);  // Sleep to simulate work
//                } catch (InterruptedException e) {
//                    Thread.currentThread().interrupt();
//                    return;  // Exit the method if the thread is interrupted
//                }
//            }
//        }
//    }
//
//    // Method to pause the thread
//    public void pauseTask() {
//        synchronized (lock) {
//            isPaused = true;  // Set pause flag to true
//        }
//    }
//
//    // Method to resume the thread
//    public void resumeTask() {
//        synchronized (lock) {
//            isPaused = false;  // Set pause flag to false
//            lock.notify();  // Notify the paused thread to resume
//        }
//    }
//
//    // Method to stop the thread
//    public void stopTask() {
//        synchronized (lock) {
//            isStopped = true;  // Set stop flag to true
//            lock.notify();  // Notify the thread to exit if it's paused
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadObjectWaitNotify threadControl = new ThreadObjectWaitNotify();
//
//        // Start the worker thread
//        Thread workerThread = new Thread(threadControl::runTask);
//        workerThread.start();
//
//        try {
//            Thread.sleep(3000);  // Let the thread run for 3 seconds
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Pause the thread
//        System.out.println("Pausing the thread...");
//        threadControl.pauseTask();
//
//        try {
//            Thread.sleep(3000);  // Let the thread remain paused for 3 seconds
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Resume the thread
//        System.out.println("Resuming the thread...");
//        threadControl.resumeTask();
//
//        try {
//            Thread.sleep(3000);  // Let the thread run for another 3 seconds
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Stop the thread
//        System.out.println("Stopping the thread...");
//        threadControl.stopTask();
//
//        try {
//            workerThread.join();  // Wait for the worker thread to finish
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//    }
//}


//https://docs.oracle.com/en%2Fjava%2Fjavase%2F22%2Fdocs%2Fapi%2F%2F/java.base/java/lang/doc-files/threadPrimitiveDeprecation.html

//public class ThreadObjectWaitNotify {
//    private final Object lock = new Object();
//    private boolean isPaused = false;
//    private boolean isStopped = false;
//
//
//    public void run() {
////        Thread thisThread = Thread.currentThread();
//        while (!isStopped) {
//            try {
//                Thread.sleep(30000);
//
//                synchronized(this) {
//                    while (isPaused)
//                        wait();
//                }
//            } catch (InterruptedException e){
//            }
//        }
//    }
//
// 
//
//    public void pauseTask() {
//        synchronized (lock) {
//            isPaused = true;  
//        }
//    }
//
//    // Method to resume the thread
//    public void resumeTask() {
//        synchronized (lock) {
//            isPaused = false;  
//            lock.notify();  
//        }
//    }
//
//    // Method to stop the thread
//    public void stopTask() {
//        synchronized (lock) {
//            isStopped = true;  
//            lock.notify();  
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadObjectWaitNotify threadControl = new ThreadObjectWaitNotify();
//
//        // Start the worker thread
//        Thread workerThread = new Thread();
//        workerThread.start();
//
//        try {
//            Thread.sleep(3000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Pause the thread
//        System.out.println("Pausing the thread...");
//        threadControl.pauseTask();
//
//        try {
//            Thread.sleep(3000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Resume the thread
//        System.out.println("Resuming the thread...");
//        threadControl.resumeTask();
//
//        try {
//            Thread.sleep(3000);  
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Stop the thread
//        System.out.println("Stopping the thread...");
//        threadControl.stopTask();
//
//        try {
//            workerThread.join();  // Wait for the worker thread to finish
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//    }
//}

public class ThreadObjectWaitNotify extends Thread {

	public volatile boolean suspended = false;
	private boolean isStoped = false;
	private Thread myThread;

	public void start() {
		myThread = new Thread(this);
		myThread.start();
	}

	@Override
	public void run() {
        while (!isStoped) {
            try {
                Thread.sleep(1000);

                synchronized(this) {
                    while (suspended) {
                    	try {
                    		this.wait();
                    	} catch (InterruptedException e) {
                    		e.printStackTrace();
                    	}
                    }
                }
            } catch (InterruptedException e){
            }
        }
    }

	public void suspendThread() {
		suspended = true;
	}

	public void resumeThread() {
		suspended = false;
		synchronized (this) {
			this.notify();
		}
	}
	

	public static void main(String[] args) {

		ThreadObjectWaitNotify threadExample = new ThreadObjectWaitNotify();

		threadExample.start();
		System.out.println("Thread is running...");

		// Let the thread run for some time
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		System.out.println("Suspending the thread...");

		threadExample.suspendThread();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		System.out.println("Resuming the thread...");

		threadExample.resumeThread();

	}
}