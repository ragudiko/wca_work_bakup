package com.ibm.test;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.charset.CoderResult;

public class CharsetConverterExample {
    public static void main(String[] args) {
    	
    	System.out.println("java version --> " +System.getProperty("java.version"));
    	
        String char_input = "WCA, Assistance!";
        Charset charset = StandardCharsets.UTF_8;
        CharsetEncoder encoder = charset.newEncoder();

        // Allocate a ByteBuffer with an estimated size
        ByteBuffer byteBuffer = ByteBuffer.allocate((int) (encoder.maxBytesPerChar() * char_input.length()));

        // Perform the conversion from char to byte
        CharBuffer charBuffer = CharBuffer.wrap(char_input);
        CoderResult result = encoder.encode(charBuffer, byteBuffer, true);

        // Handle the result if the encoding was not successful
        if (result.isError()) {
            System.out.println("Encoding error occurred.");
        } else {
            // Flip the buffer to prepare it for reading
            byteBuffer.flip();
            byte[] bytes = new byte[byteBuffer.remaining()];
            byteBuffer.get(bytes);

            // Print the byte array
            System.out.println("Converted byte array:");
            for (byte b : bytes) {
                System.out.print(b + " ");
            }
        }
    }
}

