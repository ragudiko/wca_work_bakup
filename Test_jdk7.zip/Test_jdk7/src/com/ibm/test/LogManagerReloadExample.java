package com.ibm.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class LogManagerReloadExample {

    public static void main(String[] args) {
        Logger logger = Logger.getLogger(LogManagerReloadExample.class.getName());
        LogManager logManager = LogManager.getLogManager();

        // Log before reloading configuration
        logger.info("This is an info level message before reloading.");
        logger.warning("This is a warning level message before reloading.");

        // Simulate modifying the logging.properties file (manually do this in the file)
        
     // Add a PropertyChangeListener to the LogManager
        logManager.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("LogManager configuration changed:");
                System.out.println("Property: " + evt.getPropertyName());
                System.out.println("Old Value: " + evt.getOldValue());
                System.out.println("New Value: " + evt.getNewValue());
//                try {
//                	FileInputStream fis =  new FileInputStream("src/logging.properties");
//                	LogManager.getLogManager().readConfiguration(fis);
//                } catch(IOException e) {
//                	e.printStackTrace();
//                }
             // You can access the logger levels here, after configuration is reloaded
                Logger updatedLogger = Logger.getLogger(LogManager_AddProperty.class.getName());
                System.out.println("Logger level: " + updatedLogger.getLevel());
            }
        });

        // Reload configuration from the properties file
        try (FileInputStream fis = new FileInputStream("src/logging.properties")) {
            logManager.readConfiguration(fis); // Reloads the logging properties
            System.out.println("Logging configuration reloaded.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        
     

        // Log after reloading configuration to see the effect of the changes
        logger.info("This is an info level message after reloading.");
        logger.warning("This is a warning level message after reloading.");
        logger.severe("This is a severe level message after reloading.");
    }
}

