package com.ibm.test;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;
import java.nio.charset.StandardCharsets;

public class JavaNIOCharToByteConverter {
	private java.nio.CharBuffer charBuffer;
	private java.nio.charset.CharsetEncoder encoder;
	private String encoding;
	private int nextByteIndex;
	private int nextCharIndex;

	protected JavaNIOCharToByteConverter(String encoding, boolean doNotReportError)
			throws java.io.UnsupportedEncodingException {
		encoder = java.nio.charset.Charset.forName(encoding).newEncoder();
		encoder.onMalformedInput(doNotReportError ? java.nio.charset.CodingErrorAction.REPLACE
				: java.nio.charset.CodingErrorAction.REPORT);
		encoder.onUnmappableCharacter(doNotReportError ? java.nio.charset.CodingErrorAction.REPLACE
				: java.nio.charset.CodingErrorAction.REPORT);
		encoding = encoding;
		nextByteIndex = 0;
		nextCharIndex = 0;
	}

	public int convert(char[] input, int inOff, int inEnd, byte[] output, int outOff, int outEnd)
			throws java.nio.charset.CharacterCodingException {
		int inputLength = inEnd - inOff;
		if (charBuffer == null) {
			charBuffer = java.nio.CharBuffer.allocate(inputLength);
		} else if (charBuffer.capacity() < inputLength) {
			charBuffer = java.nio.CharBuffer.allocate(inputLength);
		}
		// clear the buffer, position is 0, limit is the capacity
		charBuffer.clear();
		// position is the input (inEnd - inOff)
		charBuffer.put(input, inOff, inEnd);
		// limit is set to position, position is set to 0
		charBuffer.flip();
		nextCharIndex = inOff;
		nextByteIndex = outOff;
		java.nio.ByteBuffer byteBuffer = java.nio.ByteBuffer.wrap(output, outOff, outEnd - outOff).slice();
		java.nio.charset.CoderResult result = encoder.encode(charBuffer, byteBuffer, true);
		nextCharIndex += charBuffer.position();
		// limit is set to position, position is set to 0
		byteBuffer.flip();
		nextByteIndex += byteBuffer.limit();
		if (result.isError() || result.isOverflow())
			result.throwException();
		return byteBuffer.limit();
	}

	// called after convert call
	public int flush(byte[] outByteBuffer, int offset, int outEnd) throws java.nio.charset.CharacterCodingException {
		java.nio.ByteBuffer byteBuffer = java.nio.ByteBuffer.wrap(outByteBuffer, offset, outEnd - offset).slice();
		java.nio.charset.CoderResult result = encoder.flush(byteBuffer);
		// limit is set to position, posiition is set to 0
		byteBuffer.flip();
		nextByteIndex += byteBuffer.limit();
		if (result.isError() || result.isOverflow())
			result.throwException();
		return byteBuffer.limit();
	}
	
	public static void main(String[] args) {
		System.out.println("java version --> " +System.getProperty("java.version"));
    	
        String char_input = "Hello, World!";
        Charset charset = StandardCharsets.UTF_8;
        CharsetEncoder encoder = charset.newEncoder();
        
        try {
			JavaNIOCharToByteConverter conv = new JavaNIOCharToByteConverter(charset.name(), true);
			// Allocate a ByteBuffer with an estimated size
	        ByteBuffer byteBuffer = ByteBuffer.allocate((int) (encoder.maxBytesPerChar() * char_input.length()));

	        // Perform the conversion from char to byte
	        conv.charBuffer = CharBuffer.wrap(char_input);
//	        CoderResult result = encoder.encode(conv.charBuffer, byteBuffer, true);
	        
	        CoderResult result = conv.encoder.encode(conv.charBuffer, byteBuffer, true);

	        // Handle the result if the encoding was not successful
	        if (result.isError()) {
	            System.out.println("Encoding error occurred.");
	        } else {
	            // Flip the buffer to prepare it for reading
	            byteBuffer.flip();
	            byte[] bytes = new byte[byteBuffer.remaining()];
	            byteBuffer.get(bytes);

	            // Print the byte array
	            System.out.println("Converted byte array:");
	            for (byte b : bytes) {
	                System.out.print(b + " ");
	            }
	        }
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        
	}
}
