package com.ibm.test;

import java.util.concurrent.TimeUnit;

public class ThreadStop_EffectiveJava {
	private static boolean stopRequested;

//	public static void main(String[] args) throws InterruptedException {
//		Thread backgroundThread = new Thread(() -> {
//			int i = 0;
//			while (!stopRequested)
//				i++;
//		});
//		backgroundThread.start();
//		TimeUnit.SECONDS.sleep(1);
//		stopRequested = true;
//	}
	
	
	public static void main(String[] args) throws InterruptedException {
		Thread backgroundThread = new Thread(() -> {
			int i = 0;
			if (!stopRequested)
				while (true)
				i++;
		});
		backgroundThread.start();
		TimeUnit.SECONDS.sleep(1);
		stopRequested = true;
	}
}
