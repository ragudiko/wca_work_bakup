package com.ibm.test;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class LogManagerModifyAndReloadExample {

    public static void main(String[] args) {
        Logger logger = Logger.getLogger(LogManagerModifyAndReloadExample.class.getName());
        LogManager logManager = LogManager.getLogManager();

        // Adding a PropertyChangeListener to LogManager
        logManager.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("PropertyChangeListener triggered.");
                System.out.println("Property name: " + evt.getPropertyName());
                System.out.println("Old value: " + evt.getOldValue());
                System.out.println("New value: " + evt.getNewValue());

                Logger updatedLogger = Logger.getLogger(LogManagerModifyAndReloadExample.class.getName());
                System.out.println("Updated Logger level: " + updatedLogger.getLevel());
            }
        });

        String loggingPropertiesPath = "src/logging.properties"; // Update the path to your properties file

        // Load, modify, and save the logging.properties file
        modifyLoggingProperties(loggingPropertiesPath);

        // Reload the logging configuration
        try (FileInputStream fis = new FileInputStream(loggingPropertiesPath)) {
            logManager.readConfiguration(fis); // Reloads the logging properties
            System.out.println("Logging configuration reloaded.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Log after reloading configuration to see the effect of the changes
        logger.info("This is an info level message after reloading.");
        logger.warning("This is a warning level message after reloading.");
        logger.severe("This is a severe level message after reloading.");
    }

    private static void modifyLoggingProperties(String filePath) {
        Properties properties = new Properties();
        try (FileInputStream in = new FileInputStream(filePath)) {
            properties.load(in);

            // Modify properties (e.g., change the root logger level)
            properties.setProperty(".level", "SEVERE");
            properties.setProperty("com.ibm.test.LogManagerDetailedExample.level", "FINE");

            // Save the updated properties back to the file
            try (FileOutputStream out = new FileOutputStream(filePath)) {
                properties.store(out, null); // The second parameter is for comments
                System.out.println("logging.properties modified and saved.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
