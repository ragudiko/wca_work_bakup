package com.ibm.test;

import java.util.Scanner;
 
public class ThreadControl {

    public static boolean start = true;
    public static void main(String args[])
    {
    	ThreadStopLegacy newThread = new ThreadStopLegacy("Thread testing!");
 
        newThread.start();
 
        Scanner sc = new Scanner(System.in);
        sc.nextLine();

        ThreadControl.start = false;
        
        
    }
}