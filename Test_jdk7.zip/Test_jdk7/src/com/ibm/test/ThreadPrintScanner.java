package com.ibm.test;

class PrinterScanner {
    // Synchronized method to handle printing
    public synchronized void printDocument(String document) {
        System.out.println(Thread.currentThread().getName() + " is printing document: " + document);
        try {
            Thread.sleep(2000);  // Simulate the time taken to print a document
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(Thread.currentThread().getName() + " finished printing document: " + document);
    }

//    // Synchronized method to handle scanning
//    public synchronized void scanDocument(String document) {
//        System.out.println(Thread.currentThread().getName() + " is scanning document: " + document);
//        try {
//            Thread.sleep(3000);  // Simulate the time taken to scan a document
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//        System.out.println(Thread.currentThread().getName() + " finished scanning document: " + document);
//    }
}

// Class for print job thread
class PrintJob implements Runnable {
    private final PrinterScanner printerScanner;
    private final String document;

    public PrintJob(PrinterScanner printerScanner, String document) {
        this.printerScanner = printerScanner;
        this.document = document;
    }

    @Override
    public void run() {
        printerScanner.printDocument(document);
    }
}

public class ThreadPrintScanner {
    public static void main(String[] args) {
        PrinterScanner printerScanner = new PrinterScanner();

        // Create threads for print jobs
        Thread printThread1 = new Thread(new PrintJob(printerScanner, "Document1.pdf"), "PrintJob1");
//        Thread printThread2 = new Thread(new PrintJob(printerScanner, "Document2.pdf"), "PrintJob2");
//
//        // Create threads for scan jobs
//        Thread scanThread1 = new Thread(new ScanJob(printerScanner, "Document1.pdf"), "ScanJob1");
//        Thread scanThread2 = new Thread(new ScanJob(printerScanner, "Document2.pdf"), "ScanJob2");

        // Start the threads
        printThread1.start();
        printThread1.stop();
//        scanThread1.start();
//        printThread2.start();
//        scanThread2.start();
    }
}
