package com.ibm.test;


import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

import sun.misc.Unsafe;

public class UnsafeUtils {
	public static void main(String[] args) throws Exception {
		String sourceCode = """
				public class MyClass {
					private int value = 42;
					public MyClass(int value) {
						this.value = value;
					}
					
					public int getValue() {
						return value;
					}
				}
			""";
		
		byte[] ba = sourceCode.getBytes(StandardCharsets.UTF_8);
		doSth(ba);
	}

	private static void doSth(byte[] ba) throws Exception {
		Field f = Unsafe.class.getDeclaredField("theUnsafe");
		f.setAccessible(true);
		Unsafe unsafe = (Unsafe) f.get(null);

		Class<?> clazz = unsafe.defineAnonymousClass(UnsafeUtils.class, ba, null);

		Object obj = unsafe.allocateInstance(clazz);

		Method method = clazz.getMethod("getValue");
		int result = (int) method.invoke(obj);
		System.out.println("Result: " + result);
	}
}