package com.ibm.test;

import java.io.UnsupportedEncodingException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import sun.io.ByteToCharConverter;

public class SunIOByteToCharConverter {
	private sun.io.ByteToCharConverter btcc;

	protected SunIOByteToCharConverter(String encoding) throws java.io.UnsupportedEncodingException {
		btcc = sun.io.ByteToCharConverter.getConverter(encoding);
	}

	public int convert(byte[] rawBytes, int byteOffset, int byteEnd, char[] output, int charOffset, int charEnd)
			throws java.nio.charset.CharacterCodingException {
		try {
			return btcc.convert(rawBytes, byteOffset, byteEnd, output, charOffset, charEnd);
		} catch (sun.io.MalformedInputException e) {
		} catch (sun.io.ConversionBufferFullException e) {
		} catch (sun.io.UnknownCharacterException e) {
		}
		return -1;
	}

	public char[] convertAll(byte[] rawBytes) throws java.nio.charset.MalformedInputException {
		try {
			return btcc.convertAll(rawBytes);
		} catch (sun.io.MalformedInputException e) {
		}
		return null;
	}
	
	public static void main(String[] args) {
		
		System.out.println("java version --> " +System.getProperty("java.version"));
		
		byte[] byteArray = {72, 101, 108, 108, 111, 44, 32, 87, 111, 114, 108, 100, 33}; // "Hello, World!" in bytes
		try {
			SunIOByteToCharConverter conv = new SunIOByteToCharConverter(StandardCharsets.UTF_8.name());
			ByteToCharConverter converter = ByteToCharConverter.getConverter("UTF-8");
			char[] charArray = new char[converter.getMaxCharsPerByte() * byteArray.length];
            int charLength = conv.convert(byteArray, 0, byteArray.length, charArray, 0, charArray.length);

            // Convert the char array to a String
            String result = new String(charArray, 0, charLength);
            System.out.println("Converted String: " + result);
            
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CharacterCodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
