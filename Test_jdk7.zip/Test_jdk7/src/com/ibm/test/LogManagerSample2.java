package com.ibm.test;

import java.util.logging.LogManager;
import java.beans.PropertyChangeListener;

public class LogManagerSample2 {
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        LogManager.getLogManager().addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        LogManager.getLogManager().removePropertyChangeListener(listener);
    }
}