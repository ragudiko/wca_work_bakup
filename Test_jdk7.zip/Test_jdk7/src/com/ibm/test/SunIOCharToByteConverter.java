package com.ibm.test;

import java.io.UnsupportedEncodingException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import sun.io.CharToByteConverter;
import sun.io.ConversionBufferFullException;
import sun.io.MalformedInputException;
import sun.io.UnknownCharacterException;

public class SunIOCharToByteConverter {
	private sun.io.CharToByteConverter ctbc;

	protected SunIOCharToByteConverter(String encoding) throws java.io.UnsupportedEncodingException {
		ctbc = sun.io.CharToByteConverter.getConverter(encoding);
	}

	public int convert(char[] input, int inOffset, int inEnd, byte[] output, int outOffset, int outEnd)
			throws java.nio.charset.CharacterCodingException {
		try {
			return ctbc.convert(input, inOffset, inEnd, output, outOffset, outEnd);
		} catch (sun.io.MalformedInputException ex) {
		} catch (sun.io.UnknownCharacterException ex) {
		} catch (sun.io.ConversionBufferFullException ex) {
		}
		return -1;
	}

	public int flush(byte[] outByteBuffer, int offset, int outEnd) throws java.nio.charset.CharacterCodingException {
		try {
			return ctbc.flush(outByteBuffer, offset, outEnd);
		} catch (sun.io.MalformedInputException ex) {
		} catch (sun.io.ConversionBufferFullException ex) {
		}
		return -1;
	}

	public static void main(String a[]) {
		try {
			SunIOCharToByteConverter conv = new SunIOCharToByteConverter(StandardCharsets.UTF_8.name());

			String input = "Hello, World!";
			CharToByteConverter converter = CharToByteConverter.getConverter(StandardCharsets.UTF_8.name());
			char[] chars = input.toCharArray();
			byte[] bytes = new byte[converter.getMaxBytesPerChar() * chars.length];
			// int byteLength = converter.convert(chars, 0, chars.length, bytes, 0,
			// bytes.length);

			int byteLength = conv.convert(chars, 0, chars.length, bytes, 0, bytes.length);

			// Print the byte array
			System.out.println("Converted byte array:");
			for (int i = 0; i < byteLength; i++) {
				System.out.print(bytes[i] + " ");
			}
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//		} catch (MalformedInputException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (UnknownCharacterException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (ConversionBufferFullException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
		} catch (CharacterCodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}