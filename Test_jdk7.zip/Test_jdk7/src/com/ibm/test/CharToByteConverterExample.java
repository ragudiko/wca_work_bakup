package com.ibm.test;

import sun.io.CharToByteConverter;
import sun.io.ConversionBufferFullException;
import sun.io.MalformedInputException;
import sun.io.UnknownCharacterException;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;
import java.nio.charset.StandardCharsets;

public class CharToByteConverterExample {
    public static void main(String[] args) {
    	System.out.println("java version --> " +System.getProperty("java.version"));
    	
        String char_input = "Welcome, IBM!";
        
        before(char_input);
        after(char_input);
        /*
         * 	WCA, Assistance
         * 	Converted byte array:
				87 67 65 44 32 65 115 115 105 115 116 97 110 99 101 33 
			Converted byte array:
				87 67 65 44 32 65 115 115 105 115 116 97 110 99 101 33 
			
			WCA, IBM!
			Converted byte array:
				87 67 65 44 32 73 66 77 33 
			Converted byte array:
				87 67 65 44 32 73 66 77 33 
         */

    }
    
    static void before(String char_input) {
    	try {
        	//java 1.7 start ***************
            CharToByteConverter converter = CharToByteConverter.getConverter("UTF-8");
            char[] chars = char_input.toCharArray();
            byte[] bytes = new byte[converter.getMaxBytesPerChar() * chars.length];
            int byteLength = converter.convert(chars, 0, chars.length, bytes, 0, bytes.length);

            // Print the byte array
            System.out.println("Converted byte array:");
            for (int i = 0; i < byteLength; i++) {
                System.out.print(bytes[i] + " ");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedInputException e) {
            e.printStackTrace();
        } catch (UnknownCharacterException e) {
			e.printStackTrace();
		} catch (ConversionBufferFullException e) {
			e.printStackTrace();
		}
            //java 1.7 end ***************
    }
    
    static void after(String char_input) {
        //java 1.8 start *************** ############
        
      //            JavaNIOCharToByteConverter conv = new JavaNIOCharToByteConverter(charset.name(), true);
	            Charset charset = StandardCharsets.UTF_8;
	            CharsetEncoder encoder = charset.newEncoder();
	            
				// Allocate a ByteBuffer with an estimated size
		        ByteBuffer byteBuffer = ByteBuffer.allocate((int) (encoder.maxBytesPerChar() * char_input.length()));
	
		        // Perform the conversion from char to byte
		        
		        CharBuffer charBuffer = CharBuffer.wrap(char_input);
	//	        CoderResult result = encoder.encode(conv.charBuffer, byteBuffer, true);
		        
		        CoderResult result = encoder.encode(charBuffer, byteBuffer, true);
	
		        // Handle the result if the encoding was not successful
		        if (result.isError()) {
		            System.out.println("Encoding error occurred.");
		        } else {
		            // Flip the buffer to prepare it for reading
		            byteBuffer.flip();
		            byte[] bytes2 = new byte[byteBuffer.remaining()];
		            byteBuffer.get(bytes2);
	
		            // Print the byte array
		            System.out.println("\nConverted byte array:");
		            for (byte b : bytes2) {
		                System.out.print(b + " ");
		            }
		        }
		        
		      //java 1.8 end *************** ############
    }
}
