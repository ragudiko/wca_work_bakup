package com.ibm.test;

//public class ThreadStopSample_Interrupt implements Runnable {
//
//	@Override
//	public void run() {
//		try {
//			while (!Thread.currentThread().isInterrupted()) {
//				System.out.println("Thread is running...");
//				Thread.sleep(1000);
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread was interrupted!");
//		} finally {
//			System.out.println("Thread is terminating gracefully.");
//		}
//	}
//
//	public static void main(String[] args) throws InterruptedException {
//		Thread thread = new Thread(new ThreadStopSample_Interrupt());
//		thread.start();
//		Thread.sleep(3000);
//		thread.interrupt();
//	}
//}


//Assisted by WCA@IBM
//Latest GenAI contribution: ibm/granite-20b-code-instruct-v2
public class ThreadStopSample_Interrupt implements Runnable {
	private Thread thread;
	private volatile boolean stopped;

	public void start() {
		thread = new Thread(this);
		thread.start();
	}

	public void stop() {
		stopped = true;
		thread.interrupt();
	}

	@Override
	public void run() {
		while (!stopped) {
			try {
				// do some work
				System.out.println("Thread is running...");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Thread was interrupted!");
			}
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		ThreadStopSample_Interrupt runnable = new ThreadStopSample_Interrupt();
//		Thread thread = new Thread(runnable);
//		thread.start();
//		Thread.sleep(3000);
//		runnable.stop();
		runnable.start();
		Thread.sleep(3000);
		runnable.stop();
	}
}
