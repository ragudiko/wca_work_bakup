package com.ibm.test;

//import java.util.concurrent.CountDownLatch;
//
//public class ThreadStopLegacy extends Thread {
//	
//	public volatile boolean suspended = false;
//	
//    public CountDownLatch exitSyncObj = new CountDownLatch(1);
//    public CountDownLatch startSyncObj = new CountDownLatch(1);
//
//    private static void log(String msg) { System.out.println(msg); }
//
//    public static void main(String[] args) {
//        try {
//        	System.out.println("load some agent");
//            log("Loaded agent: ");
//        } catch (UnsatisfiedLinkError ule) {
//            log("Failed to load agent: ");
//            throw ule;
//        }
//
//        Thread threadCreator = new Thread() {
//            @Override
//            public void run() {
//                while (!suspended) {
//                    Thread dummyThread = new Thread(() -> {});
//                    dummyThread.start();
//                    try {
//                        dummyThread.join();
//                    } catch(InterruptedException ie) {
//                    }
//                }
//            }
//        };
//        threadCreator.setDaemon(true);
//        threadCreator.start();
//
//    }
//
//    public String suspendThread(ThreadStopLegacy th) {
//    	suspended = true;
//    	th.suspend();
//    	return "no error";
//    }
//    
//    public String resumeThread(ThreadStopLegacy th) {
//    	suspended = false;
//    	th.resume();
//    	return "no error";
//    }
//    
//    public static void test(int timeMax) {
//        System.out.println("About to execute for " + timeMax + " seconds.");
//
//        long count = 0;
//        long start_time = System.currentTimeMillis();
//        while (System.currentTimeMillis() < start_time + (timeMax * 1000)) {
//            count++;
//
//            String retCode;
//            ThreadStopLegacy thread = new ThreadStopLegacy();
//            thread.start();
//            try {
//                // Wait for the worker thread to get going.
//                thread.startSyncObj.await();
//
//                thread.exitSyncObj.countDown();
//                while (true) {
//                	retCode = thread.suspendThread(thread);
//
//                    if (retCode.equals("no error")) {
//                        break;
//                    } else  {
//                        throw new RuntimeException("thread " + thread.getName()
//                                                   + ": suspendThread() " +
//                                                   "retCode=" + retCode +
//                                                   ": unexpected value.");
//                    }
//
//                    retCode = thread.resumeThread(thread);
//                    if (!retCode.equals("no error")) {
//                        throw new RuntimeException("thread " + thread.getName()
//                                                   + ": resumeThread() " +
//                                                   "retCode=" + retCode +
//                                                   ": unexpected value.");
//                    }
//                }
//            } catch (InterruptedException e) {
//                throw new RuntimeException("Unexpected: " + e);
//            }
//
//        }
//    }
//
//}

//class for tested threads
//public class ThreadStopLegacy extends Thread {
// private volatile boolean threadReady = false;
// private volatile boolean suspended = false;
// private volatile boolean shouldFinish = false;
//
// // make thread with specific name
// public ThreadStopLegacy(String name) {
//     super(name);
// }
//
// // run thread continuously
// public void run() {
//     // run in a loop
//     threadReady = true;
//     int i = 0;
//     int n = 1000;
//     while (!shouldFinish) {
//    	 if(!suspended) {
//         if (n <= 0) {
//             n = 1000;
//             try {
//				Thread.sleep(10);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//         }
//         if (i > n) {
//             i = 0;
//             n = n - 1;
//         }
//         i = i + 1;
//         System.out.println("value of i" + i);
//     }
//     }
// }
//
////ensure thread is ready
// public void ensureReady() {
//     try {
//         while (!threadReady) {
//             sleep(1000);
//         }
//     } catch (InterruptedException e) {
//         throw new RuntimeException("Interruption while preparing tested thread: \n\t" + e);
//     }
// }
// 
// // let thread to finish
// public void letFinish() {
//     shouldFinish = true;
// }
// 
//public String suspendThread(ThreadStopLegacy th) {
//	suspended = true;
//	th.suspend();
//	return "no error";
//}
//
//public String resumeThread(ThreadStopLegacy th) {
//	suspended = false;
//	th.resume();
//	return "no error";
//}
// 
// public static void main(String a[]) {
//	 ThreadStopLegacy th = new ThreadStopLegacy("MyThread");
//	 th.start();
//	 th.ensureReady();
//	 String retcode=null;
//	 retcode = th.suspendThread(th);
//	 if(!retcode.equals("no error"))
//		 System.out.println("do something");
//	 retcode = th.resumeThread(th);
//	 if(!retcode.equals("no error"))
//		 System.out.println("do something");
//	 
//	 th.letFinish();
// }
//}

//public class ThreadStopLegacy extends Thread {
//	 private volatile boolean threadReady = false;
//	 private volatile boolean suspended = false;
//	 private volatile boolean shouldFinish = false;
//
//	 // make thread with specific name
//	 public ThreadStopLegacy(String name) {
//	     super(name);
//	 }
//
//	 // run thread continuously
//	 public void run() {
//	     // run in a loop
//	     threadReady = true;
//	     int i = 0;
//	     int n = 1000;
//	     while (!shouldFinish) {
//	    	 if(!suspended) {
//	         if (n <= 0) {
//	             n = 1000;
//	             try {
//					Thread.sleep(10);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//	         }
//	         if (i > n) {
//	             i = 0;
//	             n = n - 1;
//	         }
//	         i = i + 1;
//	         System.out.println("value of i" + i);
//	     }
//	     }
//	 }
//
//	//ensure thread is ready
//	 public void ensureReady() {
//	     try {
//	         while (!threadReady) {
//	             sleep(1000);
//	         }
//	     } catch (InterruptedException e) {
//	         throw new RuntimeException("Interruption while preparing tested thread: \n\t" + e);
//	     }
//	 }
//	 
//	 // let thread to finish
//	 public void letFinish() {
//	     shouldFinish = true;
//	 }
//	 
//	public String suspendThread() {
//		suspended = true;
//		try {
//			this.wait();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		return "no error";
//	}
//
//	public String resumeThread() {
//		suspended = false;
//		this.notify();
//		return "no error";
//	}
//	 
//	 public static void main(String a[]) {
//		 ThreadStopLegacy th = new ThreadStopLegacy("MyThread");
//		 th.start();
//		 th.ensureReady();
//		 String retcode=null;
//		 retcode = th.suspendThread();
//		 if(!retcode.equals("no error"))
//			 System.out.println("do something");
//		 retcode = th.resumeThread();
//		 if(!retcode.equals("no error"))
//			 System.out.println("do something");
//		 
//		 th.letFinish();
//	 }
//	}


//public class ThreadStopLegacy extends Thread {
//    private boolean suspended = false;  // Used to suspend/resume the thread
//    private boolean stopped = false;    // Used to stop the thread
//
//    @Override
//    public void run() {
//        synchronized (this) {
//            while (!stopped) {
//                if (suspended) {
//                    try {
//                        System.out.println("Thread is suspended...");
//                        wait();  // Thread waits here
//                    } catch (InterruptedException e) {
//                        Thread.currentThread().interrupt();
//                    }
//                }
//
//                // Simulate some work
//                //if (!stopped) {
//                    System.out.println("Thread is running...");
//                    try {
//                        Thread.sleep(1000);
//                    } catch (InterruptedException e) {
//                        Thread.currentThread().interrupt();
//                    }
//                //}
//            }
//            System.out.println("Thread has stopped.");
//        }
//    }
//
//    // Safely suspend the thread
//    public void suspendThread() {
////        synchronized (this) {
//            suspended = true;
////        }
//    }
//
//    // Safely resume the thread
//    public void resumeThread() {
//        synchronized (this) {
//            suspended = false;
//            notify();  // Wake up the thread from wait
//        }
//    }
//
//    // Safely stop the thread
//    public void stopThread() {
//        synchronized (this) {
//            stopped = true;
//            suspended = false;  // Ensure the thread is not suspended anymore
//            notify();  // Wake up the thread if it's waiting
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy thread = new ThreadStopLegacy();
//        thread.start();
//
//        try {
//            Thread.sleep(3000);  // Let the thread run for a bit
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//        System.out.println("Suspend the thread...");
//        thread.suspendThread();  // Suspend the thread
//
//        try {
//            Thread.sleep(3000);  // Simulate some delay while the thread is suspended
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//        System.out.println("Resume the thread...");
//        thread.resumeThread();  // Resume the thread
//        
//        System.out.println("Stopping the thread...");
//        thread.stopThread();  // Stop the thread
//
//        try {
//            thread.join();  // Wait for the thread to finish
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//    }
//}


import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class ThreadStopLegacy extends Thread {

	private Thread myThread;
	public volatile boolean suspended = false;
	
	@Override
	public void run() {
		try {
			while (true) {
				if(suspended) {
					synchronized (this) {
						try {
							this.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
					
				ReadableByteChannel rbc = new ReadableByteChannel() {
					public int read(ByteBuffer dst) {
						dst.put((byte) 0);
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						return 1;
					}

					public boolean isOpen() {
						return true;
					}

					public void close() {
					}
				};
				Thread.sleep(1500);
				InputStream in = Channels.newInputStream(rbc);
				byte[] b = new byte[3];
				in.read(b, 0, 1);
				in.read(b, 2, 1); // throws IAE
			}
		} catch (InterruptedException e) {
			System.out.println("Thread interrupted during operation.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void start() {
		myThread = new Thread(this);
		myThread.start();
	}

	public void suspendThread() {
		suspended = true;
	}

	public void resumeThread() {
		suspended = false;
		synchronized (this) {
			this.notify();
		}
	}

	public static void main(String[] args) throws IOException {

		ThreadStopLegacy legacyThread = new ThreadStopLegacy();
		legacyThread.start();

		try {
			Thread.sleep(5000); // Let the thread insert some data
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Start the Thread");
		legacyThread.start();
		
		System.out.println("Suspend the Thread");
		legacyThread.suspendThread();
		
		System.out.println("Resume the Thread");
		legacyThread.resumeThread();

	}

}


//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;


//import java.io.FileWriter;
//import java.io.IOException;
//
//public class ThreadStopLegacy extends Thread {
//    @Override
//    public void run() {
//        try (FileWriter filewriter = new FileWriter("output.txt")) {
//            while (true) {
//                filewriter.write("Writing some data...\n");
//                filewriter.flush();
//                System.out.println("File is being written...");
//                Thread.sleep(1000);
//            }
//        } catch (InterruptedException | IOException e) {
//            System.out.println("Thread interrupted or IO exception occurred.");
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy thread = new ThreadStopLegacy();
//        thread.start();
//
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        thread.stop(new IOException("Forcing the thread to stop with an IOException."));
//    }
//}

//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.ByteBuffer;
//import java.nio.channels.Channels;
//import java.nio.channels.ReadableByteChannel;
//
//public class ThreadStopLegacy extends Thread {
//
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopLegacy legacyThread = new ThreadStopLegacy();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		legacyThread.stop(new RuntimeException("Forcing the thread to stop during operation."));
//
//	}
//
//}



//public class ThreadStopLegacy extends Thread {
//
//	String document = "Document1"; 
//	public volatile boolean suspended = false;
//
//	public synchronized void printDocument(String document) {
//		while (!suspended) {
//			System.out.println(Thread.currentThread().getName() + " printing sample document: " + document);
//			try {
//				wait(2000);
//			} catch (InterruptedException e) {
//				Thread.currentThread().interrupt();
//			}
//			System.out.println(Thread.currentThread().getName() + " done with printing document: " + document);
//		}
//	}
//
//	@Override
//	public void run() {
//		printDocument(document);
//	}
//
//	public void suspendThread() {
//		suspended = true;
//	}
//
//	public void resumeThread() {
//		suspended = false;
//		synchronized (this) {
//			notify();
//		}
//	}
//
//	public static void main(String[] args) {
//		ThreadStopLegacy printerSample = new ThreadStopLegacy();
//
//		printerSample.start();
//
//		try {
//			Thread.sleep(2000); 
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//
//		System.out.println(" suspend the thread");
//		printerSample.suspendThread();
//
//		try {
//			Thread.sleep(5000); 
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//		System.out.println(" resume the thread");
//		printerSample.resumeThread();
//		
//	}
//}


//Ex2
//public class ThreadStopLegacy extends Thread {
//    @Override
//    public void run() {
//        try {
//            while (true) {
//                // Simulate network request processing
//                System.out.println("Processing network request...");
//                Thread.sleep(2000);
//            }
//        } catch (InterruptedException e) {
//            System.out.println("Thread interrupted.");
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy thread = new ThreadStopLegacy();
//        thread.start();
//
//        try {
//            Thread.sleep(6000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        thread.stop(new RuntimeException("Stopping the thread with a RuntimeException."));
//    }
//}

 //Ex3
//public class ThreadStopLegacy extends Thread {
//    @Override
//    public void run() {
//        try {
//            int result = 0;
//            for (int i = 1; i <= 100; i++) {
//                result += i;
//                if (i % 100 == 0) {
//                    System.out.println("Current result: " + result + " i: " + i);
//                }
//            }
//        } catch (ArithmeticException e) {
//            System.out.println("Thread stopped because of arithmetic error.");
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy legacyThread = new ThreadStopLegacy();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(3000); 
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        legacyThread.stop(new ArithmeticException("Force the thread to stop with an ArithmeticException."));
//    }
//}

//Ex4
//public class ThreadStopLegacy extends Thread {
//    @Override
//    public void run() {
//        try {
//            for (int i = 1; i <= 10; i++) {
//                System.out.println("Start downloading data chunks " + i + "...");
//                Thread.sleep(1000);
//            }
//        } catch (InterruptedException e) {
//            System.out.println("Thread interrupted during download.");
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy legacyThread = new ThreadStopLegacy();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(4000);  // Let the thread download a few chunks of data
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Dangerous method: Thread.stop(Throwable t)
//        legacyThread.stop(new RuntimeException("Forcing the thread to stop during data download."));
//    }
//}

//public class ThreadStopLegacy extends Thread {
//    @Override
//    public void run() {
//        try {
//            while (true) {
//                // Simulate database operations
//                System.out.println("Inserting data into database...");
//                Thread.sleep(1500);
//            }
//        } catch (InterruptedException e) {
//            System.out.println("Thread interrupted during database operation.");
//        }
//    }
//
//    public static void main(String[] args) {
//        ThreadStopLegacy legacyThread = new ThreadStopLegacy();
//        legacyThread.start();
//
//        try {
//            Thread.sleep(5000);  // Let the thread insert some data
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Dangerous method: Thread.stop(Throwable t)
//        legacyThread.stop(new RuntimeException("Forcing the thread to stop during a database operation."));
//    }
//}

//public class ThreadStopLegacy extends Thread {
//
//	@Override
//	public void run() {
//		try {
//			while (true) {
//				ReadableByteChannel rbc = new ReadableByteChannel() {
//					public int read(ByteBuffer dst) {
//						dst.put((byte) 0);
//						try {
//							Thread.sleep(1000);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//						return 1;
//					}
//
//					public boolean isOpen() {
//						return true;
//					}
//
//					public void close() {
//					}
//				};
//				Thread.sleep(1500);
//				InputStream in = Channels.newInputStream(rbc);
//				byte[] b = new byte[3];
//				in.read(b, 0, 1);
//				in.read(b, 2, 1); // throws IAE
//			}
//		} catch (InterruptedException e) {
//			System.out.println("Thread interrupted during database operation.");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	public static void main(String[] args) throws IOException {
//
//		ThreadStopLegacy legacyThread = new ThreadStopLegacy();
//		legacyThread.start();
//
//		try {
//			Thread.sleep(5000); // Let the thread insert some data
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//
//		// Dangerous method: Thread.stop(Throwable t)
//		legacyThread.stop(new RuntimeException("Forcing the thread to stop during a database operation."));
//
//	}
//
//}

