package com.ibm.test;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class LogManager_AddProperty2 {
	
//	final Logger logger = Logger.getLogger(LogManager_AddProperty2.class.getName());
//    LogManager logManager = LogManager.getLogManager();
    
    private String level;
    
    private PropertyChangeSupport support;

    public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		support.firePropertyChange("info", this.level, level);
		this.level = level;
		System.out.println("firePropertyChange");
	}	

    public LogManager_AddProperty2() {
        support = new PropertyChangeSupport(this);
    }

    public void addPropertyChangeListener(PropertyChangeListener pcl) {
        support.addPropertyChangeListener(pcl);
        System.out.println("triggered addPropertyChangeListener");
    }

    public void removePropertyChangeListener(PropertyChangeListener pcl) {
        support.removePropertyChangeListener(pcl);
    }

    
    public static void main(String a[]) {
    	LogManager_AddProperty2 observable = new LogManager_AddProperty2();
    	LogManagerChannel observer = new LogManagerChannel();

    	observable.addPropertyChangeListener(observer);
    	observable.setLevel("info");

    	System.out.println(observer.getLevel()+ "info");
    	
    }
   
   
    
}


