package com.ibm.test;

public class ThreadStopSample_Variable implements Runnable {
	private volatile boolean running = true;

	@Override
	public void run() {
		while (running) {
			System.out.println("Thread is running...");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
		System.out.println("Thread is terminating gracefully.");
	}

	public void stop() {
		running = false;
	}

	public static void main(String[] args) throws InterruptedException {
		ThreadStopSample_Variable runnable = new ThreadStopSample_Variable();
		Thread thread = new Thread(runnable);
		thread.start();
		Thread.sleep(3000);
		runnable.stop();
	}
}
