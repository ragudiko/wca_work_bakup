package com.ibm.test;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class PCLNewsAgency {
    private String news;

    private PropertyChangeSupport support;

    public PCLNewsAgency() {
        support = new PropertyChangeSupport(this);
    }

    public void addPropertyChangeListener(PropertyChangeListener pcl) {
        support.addPropertyChangeListener(pcl);
        System.out.println("triggered addPropertyChangeListener");
    }

    public void removePropertyChangeListener(PropertyChangeListener pcl) {
        support.removePropertyChangeListener(pcl);
    }

    public void setNews(String value) {
        support.firePropertyChange("news", this.news, value);
        this.news = value;
        System.out.println("firePropertyChange");
    }
    
    public static void main(String a[]) {
    	PCLNewsAgency observable = new PCLNewsAgency();
    	PCLNewsChannel observer = new PCLNewsChannel();

    	observable.addPropertyChangeListener(observer);
    	observable.setNews("news");

    	System.out.println(observer.getNews()+ "news");
    	
    }
}