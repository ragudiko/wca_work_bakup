package com.ibm.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class CustomLogManager extends LogManager {

    public CustomLogManager() {
        super();
        System.out.println("CustomLogManager initialized.");
    }

    @Override
    public void readConfiguration() throws IOException, SecurityException {
        super.readConfiguration();
        Logger logger = Logger.getLogger(CustomLogManager.class.getName());
        logger.info("Logging configuration has been reloaded.");

        notifyLoggers();
    }

    private void notifyLoggers() {
        Logger logger = Logger.getLogger(CustomLogManager.class.getName());
        logger.setLevel(Level.FINE);
        logger.info("Custom notification: All loggers should refresh their settings.");
    }

    public static void main(String[] args) {
        System.setProperty("java.util.logging.manager", CustomLogManager.class.getName());
//      LogManager logManager = LogManager.getLogManager();
        CustomLogManager customLogManager = new CustomLogManager();
        
   	 	final Logger logger = Logger.getLogger(CustomLogManager.class.getName());
//   	 	LogManager logManager = CustomLogManager.getLogManager();

        customLogManager.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("Logging configuration changed.");
                System.out.println("Property name: " + evt.getPropertyName());
                System.out.println("Old value: " + evt.getOldValue());
                System.out.println("New value: " + evt.getNewValue());

                // You can access the logger levels here, after configuration is reloaded
                Logger updatedLogger = Logger.getLogger(logger.getName());
                System.out.println("Updated Logger level: " + updatedLogger.getLevel());
            }
        });
        
        try {
        	customLogManager.readConfiguration();
        } catch (IOException | SecurityException e) {
            e.printStackTrace();
        }

        Logger logger2 = Logger.getLogger(CustomLogManager.class.getName());
        logger2.info("This is a log message after the configuration reload.");
    }
}


