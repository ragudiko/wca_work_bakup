package com.ibm.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ReadOnlyBufferException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class Test {

	
	public static void main(String[] args) throws IOException {
		
		String message = "ascii data for a test";
		int ITERATIONS = 500;
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		byte[] introBytes = outputStream.toByteArray();
		 
		ByteArrayInputStream inputStream = new ByteArrayInputStream(introBytes);
		//flags
		ReadableByteChannel rbc = Channels.newChannel(inputStream);
		int messageSize = message.length() * ITERATIONS * 3;
        byte data[] = new byte[messageSize+1];
        ByteBuffer bb = ByteBuffer.wrap(data);
        try {
            rbc.read(bb.asReadOnlyBuffer());
            //throw new RuntimeException("IllegalArgumentException not thrown");
        } catch (ReadOnlyBufferException expected) {
        	System.out.println("ReadOnlyBufferException");
        }
        catch (IllegalArgumentException expected) {
            System.out.println("IllegalArgumentException");
        }
        
        
//        File file = new File("abc.txt");
//        ExtendedFileInputStream fis = new ExtendedFileInputStream(file);
////        ReadableByteChannel rbc = Channels.newChannel(fis);
//
////        int messageSize = message.length() * ITERATIONS * 3;
////        byte data[] = new byte[messageSize+1];
////        ByteBuffer bb = ByteBuffer.wrap(data);
//
//        try {
//            rbc.read(bb.asReadOnlyBuffer());
//            //throw new RuntimeException("IllegalArgumentException not thrown");
//        } catch (ReadOnlyBufferException expected) {
//        	System.out.println("ReadOnlyBufferException");
//        }
//        catch (IllegalArgumentException expected) {
//        	System.out.println("IllegalArgumentException");
//        }
//        System.out.println("success");
	}
	
}

class ExtendedFileInputStream extends java.io.FileInputStream {
    ExtendedFileInputStream(File file) throws FileNotFoundException {
        super(file);
    }
}

class ExtendedFileOutputStream extends java.io.FileOutputStream {
    ExtendedFileOutputStream(File file) throws FileNotFoundException {
        super(file);
    }
}
