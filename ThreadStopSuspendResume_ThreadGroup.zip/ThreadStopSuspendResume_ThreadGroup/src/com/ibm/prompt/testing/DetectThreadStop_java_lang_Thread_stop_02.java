package com.ibm.prompt.testing;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class DetectThreadStop_java_lang_Thread_stop_02 extends Thread {

	private Thread myThread;
	
	@Override
	public void run() {
		try {
			while (true) {
				ReadableByteChannel rbc = new ReadableByteChannel() {
					public int read(ByteBuffer dst) {
						dst.put((byte) 0);
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						return 1;
					}

					public boolean isOpen() {
						return true;
					}

					public void close() {
					}
				};
				Thread.sleep(1500);
				InputStream in = Channels.newInputStream(rbc);
				byte[] b = new byte[3];
				in.read(b, 0, 1);
				in.read(b, 2, 1); // throws IAE
			}
		} catch (InterruptedException e) {
			System.out.println("Thread interrupted during operation.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void start() {
		myThread = new Thread(this);
		myThread.start();
	}

	public void stopThread() {
		myThread.stop();
	}

	public static void main(String[] args) throws IOException {

		DetectThreadStop_java_lang_Thread_stop_02 legacyThread = new DetectThreadStop_java_lang_Thread_stop_02();
		legacyThread.start();

		try {
			Thread.sleep(5000); // Let the thread insert some data
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Start the Thread");
		legacyThread.start();
		
		System.out.println("Stop the Thread");
		legacyThread.stopThread();

	}

}
