package com.ibm.prompt.testing;


public class DetectThreadStop_java_lang_Thread_stop_01 extends Thread {
    @Override
    public void run() {
        while(true) {
            // keep doing what this thread should do.
            System.out.println("Thread is Running");

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    public static void main(String[] args) {
        DetectThreadStop_java_lang_Thread_stop_01 legacyThread = new DetectThreadStop_java_lang_Thread_stop_01();
        legacyThread.start();

        try {
            Thread.sleep(9000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Stop the Thread");
        legacyThread.stop();
        
        ThreadGroup group = new ThreadGroup("foo");

		group.allowThreadSuspension(true);	
    }
}
