package com.ibm.prompt.testing;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class OutputStreamWriterExtend extends OutputStreamWriter {

	public OutputStreamWriterExtend(OutputStream out) {
		super(out);
		// TODO Auto-generated constructor stub
	}
	public static void printStreamCheckPrime7() throws IOException {
		int n = 18;
	    boolean isNotPrime = false;
	    if (n <= 1) {
	        isNotPrime = true;
	    } else {
	        for (int i = 2; i <= Math.sqrt(n); i++) {
	            if (n % i == 0) {
	                isNotPrime = true;
	                break;
	            }
	        }
	    }
	    Writer out = new OutputStreamWriterExtend(System.out);
	    out.write("isNotPrime: " + isNotPrime);
	    out.close();
	}
}
