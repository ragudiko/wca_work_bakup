package com.ibm.jsf;

import java.io.Serializable;
//import com.sun.faces.application.*;
//import com.sun.faces.util.DebugUtil;
import org.apache.myfaces.application.*;
//import org.apache.myfaces.cdi.*;

public class HelloWorldJSFManagedBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private UserFormView userFormView;

	public HelloWorldJSFManagedBean() {
		this.userFormView = new UserFormView();
	}

	public UserFormView getUserFormView() {
		return userFormView;
	}

	public void setUserFormView(UserFormView userFormView) {
		this.userFormView = userFormView;
	}

	public String showUserDetails() {
		System.out.println("The Name Of the user is :" + this.userFormView.getUserName());
		return "welcomePage";
	}
	
//	public void dummyMethod() {
//		DebugUtil.waitForDebugger();
//	}
	
	public void someMethod() {
		ApplicationImpl obj = new ApplicationImpl();
		System.out.println(obj.MYFACES_PROJECT_STAGE_SYSTEM_PROPERTY_NAME);
	}
}
