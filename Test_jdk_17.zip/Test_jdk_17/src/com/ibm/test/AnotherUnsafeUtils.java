package com.ibm.test;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

import sun.misc.Unsafe;

public class AnotherUnsafeUtils {

	public static void main(String[] args) throws Exception {
		String sourceCode = args[0];
		byte[] bytes = sourceCode.getBytes(StandardCharsets.UTF_8);
		AnotherUnsafeUtils utils = new AnotherUnsafeUtils();
		utils.process(bytes);
	}
	
	private void process(byte[] bytes) throws Exception {
		final Unsafe unsafe = Unsafe.getUnsafe();
		
		Class<?> clazz1 = unsafe.defineAnonymousClass(AnotherUnsafeUtils.class, bytes, null);
		Object obj1 = unsafe.allocateInstance(clazz1);
		
		Class<?> clazz2 = unsafe.defineAnonymousClass(AnotherUnsafeUtils.class, bytes, null);
		Object obj2 = unsafe.allocateInstance(clazz2);
		
		if (obj1 == obj2) {
			System.err.println("The objects are not expected to be equal");
		} else {
			Method method1 = clazz1.getMethod("toString");
			method1.invoke(obj1);
			Method method2 = clazz2.getMethod("toString");
			method2.invoke(obj2);
		}
	}
}
